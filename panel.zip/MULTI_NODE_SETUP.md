# Multi-Node System Setup Guide

## Overview
This multi-node system allows you to connect multiple VPS/servers to your Minecraft panel, distributing your servers across different machines for better performance and reliability!

## Files Included
- `node-agent.js` - The node agent daemon that runs on your remote VPS
- `node-agent.service` - Systemd service file for Linux (runs agent in background)
- `install-node-agent.sh` - Automatic installation script for Linux
- `install-node-agent.ps1` - Automatic installation script for Windows
- `.agent-env.example` - Example configuration file
- [Panel files already integrated]

---

## Step 1: Create a Node in the Panel
1. Go to your panel's admin area
2. Navigate to **Nodes**
3. Click **Add Node**
4. Fill out the form:
   - **Name**: Give your node a name (e.g., "US-East-1")
   - **Address**: Enter your VPS IP address or domain (e.g., `192.168.1.100` or `node1.mypanel.com`)
   - **Port**: Default is `3001` (you can change it if needed)
   - **API Key**: Click "Generate" to create a secure API key (copy this key!)
5. Click **Test Connection** to verify (it will fail now since we haven't set up the agent yet)
6. Save the node

---

## Step 2: Set up the Node Agent on Linux VPS
1. **Connect to your VPS via SSH** (as root or a user with sudo)
2. **Download or copy the setup files** to your VPS
3. **Make the script executable** and run it:
   ```bash
   chmod +x install-node-agent.sh
   ./install-node-agent.sh
   ```
4. **Configure the agent**:
   Edit the config file:
   ```bash
   nano /opt/minecraft-panel-node/.agent-env
   ```
   Update the API key to match what you generated in the panel:
   ```env
   AGENT_PORT=3001
   AGENT_API_KEY=your-generated-api-key-here
   ```
   Save and exit (Ctrl+X, Y, Enter)

5. **Start the agent**:
   ```bash
   systemctl start node-agent
   ```

6. **Enable auto-start on boot**:
   ```bash
   systemctl enable node-agent
   ```

7. **Check status**:
   ```bash
   systemctl status node-agent
   ```

8. **View logs (if needed)**:
   ```bash
   journalctl -u node-agent -f
   ```

---

## Step 3: Set up the Node Agent on Windows VPS
1. **Connect to your Windows VPS via RDP**
2. **Open PowerShell as Administrator**
3. **Download or copy the setup files**
4. **Run the installation script**:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   .\install-node-agent.ps1
   ```

5. **Configure the agent**:
   - Navigate to `C:\Program Files\Minecraft Panel Node Agent`
   - Edit `.agent-env` with Notepad
   - Update `AGENT_API_KEY` to match your panel's key

6. **Start the agent**:
   Double-click `start-node-agent.bat`

7. **Optional: Set up auto-start**:
   - Press Win+R, type `shell:startup`
   - Create a shortcut to `start-node-agent.bat` in the startup folder

---

## Step 4: Verify Connection
1. Go back to your panel's Nodes page
2. Click **Edit** on your new node
3. Click **Test Connection**
4. You should see a success message!
5. The node will now show as "Online" in the nodes list!

---

## Node Agent API Endpoints
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check (no auth) |
| `/api/stats` | GET | Get node resource stats |
| `/api/servers` | GET | List servers on node |
| `/api/servers/:id/create` | POST | Create server directory |
| `/api/servers/:id/start` | POST | Start a server |
| `/api/servers/:id/stop` | POST | Stop a server |
| `/api/servers/:id/status` | GET | Get server status |

---

## Firewall Configuration
Make sure port **3001** (or your custom port) is open:
- **Linux (UFW)**: `ufw allow 3001/tcp`
- **Linux (Firewalld)**: 
  ```bash
  firewall-cmd --permanent --add-port=3001/tcp
  firewall-cmd --reload
  ```
- **Windows**: The setup script does this automatically, or:
  - Go to Windows Defender Firewall → Advanced Settings
  - Add an inbound rule for TCP port 3001

---

## Troubleshooting
### Node shows as Offline
1. Check if the agent is running:
   - Linux: `systemctl status node-agent`
   - Windows: Check if the node-agent window is open
2. Verify API key matches in both panel and `.agent-env`
3. Check firewall settings
4. Test with `curl http://your-node-ip:3001/health`
5. Check agent logs for errors

### Can't connect to node
1. Verify port is open (use an online port checker tool like https://canyouseeme.org/)
2. Make sure your VPS provider's firewall allows the port
3. Check if your node is listening on `0.0.0.0` (not just 127.0.0.1)

---

## Next Steps
Now that your node is connected, you can:
- Assign servers to this node when creating them
- Monitor node resource usage in real-time
- Add more nodes to scale your infrastructure!
