-- Multi-node allocations update
-- Creates allocations table and updates servers table

-- Create allocations table
CREATE TABLE IF NOT EXISTS allocations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id INTEGER NOT NULL,
    ip_address TEXT NOT NULL,
    port INTEGER NOT NULL,
    server_id INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL
);

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_allocations_node_id ON allocations(node_id);
CREATE INDEX IF NOT EXISTS idx_allocations_server_id ON allocations(server_id);

-- Add node_id and allocation_id to servers table if not exists
ALTER TABLE servers ADD COLUMN node_id INTEGER DEFAULT NULL REFERENCES nodes(id) ON DELETE SET NULL;
ALTER TABLE servers ADD COLUMN allocation_id INTEGER DEFAULT NULL REFERENCES allocations(id) ON DELETE SET NULL;
