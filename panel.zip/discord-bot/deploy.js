const { REST, Routes, SlashCommandBuilder } = require('discord.js');
const config = require('./config.json');

const commands = [
  new SlashCommandBuilder().setName('help').setDescription('Show all commands'),
  new SlashCommandBuilder().setName('servers').setDescription('List your servers'),
  new SlashCommandBuilder().setName('server').setDescription('View server details')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  ...[['start','Start'],['stop','Stop'],['restart','Restart'],['kill','Force kill']].map(([n,d]) =>
    new SlashCommandBuilder().setName(n).setDescription(`${d} a server`)
      .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true))),
  new SlashCommandBuilder().setName('command').setDescription('Send a console command')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true))
    .addStringOption(o => o.setName('command').setDescription('Command').setRequired(true)),
  new SlashCommandBuilder().setName('console').setDescription('View console output')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  new SlashCommandBuilder().setName('players').setDescription('View online players')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  new SlashCommandBuilder().setName('backups').setDescription('List backups')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  new SlashCommandBuilder().setName('me').setDescription('Your linked panel account & servers'),
  new SlashCommandBuilder().setName('link').setDescription('Link Discord user to panel account (admin)')
    .addUserOption(o => o.setName('user').setDescription('Discord user').setRequired(true))
    .addIntegerOption(o => o.setName('panel_id').setDescription('Panel user ID').setRequired(true)),
  new SlashCommandBuilder().setName('unlink').setDescription('Unlink Discord user (admin)')
    .addUserOption(o => o.setName('user').setDescription('Discord user').setRequired(true)),
  new SlashCommandBuilder().setName('links').setDescription('List all Discord links (admin)'),
  new SlashCommandBuilder().setName('nodes').setDescription('List all nodes (admin)'),
  new SlashCommandBuilder().setName('node').setDescription('Node details (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('Node ID').setRequired(true)),
  new SlashCommandBuilder().setName('node-refresh').setDescription('Refresh node stats (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('Node ID').setRequired(true)),
  new SlashCommandBuilder().setName('users').setDescription('List all users (admin)'),
  new SlashCommandBuilder().setName('user').setDescription('User details (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('User ID').setRequired(true)),
  new SlashCommandBuilder().setName('user-create').setDescription('Create a user (admin)')
    .addStringOption(o => o.setName('username').setDescription('Username').setRequired(true))
    .addStringOption(o => o.setName('email').setDescription('Email').setRequired(true))
    .addStringOption(o => o.setName('password').setDescription('Password').setRequired(true))
    .addStringOption(o => o.setName('role').setDescription('Role').addChoices({name:'user',value:'user'},{name:'admin',value:'admin'})),
  new SlashCommandBuilder().setName('user-delete').setDescription('Delete a user (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('User ID').setRequired(true)),
  new SlashCommandBuilder().setName('panel-stats').setDescription('Panel statistics (admin)'),
];

const rest = new REST({ version: '10' }).setToken(config.token);

(async () => {
  try {
    console.log('Registering slash commands...');
    if (config.adminGuildId) {
      await rest.put(Routes.applicationGuildCommands(config.clientId, config.adminGuildId), {
        body: commands.map(c => c.toJSON()),
      });
      console.log(`✅ Guild commands registered in ${config.adminGuildId}`);
    } else {
      await rest.put(Routes.applicationCommands(config.clientId), {
        body: commands.map(c => c.toJSON()),
      });
      console.log('✅ Global commands registered (may take up to 1 hour to appear)');
    }
  } catch (err) {
    console.error('❌ Failed to register commands:', err.message);
  }
})();
