const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, bold } = require('discord.js');
const axios = require('axios');
const config = require('./config.json');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// ===== API Client =====
const api = axios.create({
  baseURL: config.panelUrl + '/api',
  headers: { Authorization: `Bearer ${config.apiKey}` }
});

// Track if we have the discord linking header available
// When linked users make requests, we pass X-Panel-User-Id
async function apiAs(endpoint, method = 'GET', data = null, panelUserId = null) {
  const headers = {};
  if (panelUserId) headers['X-Panel-User-Id'] = panelUserId;
  const res = await api({ method, url: endpoint, data, headers });
  return res.data;
}

function apiGet(endpoint) { return api.get(endpoint).then(r => r.data); }
function apiPost(endpoint, d) { return api.post(endpoint, d).then(r => r.data); }
function apiDelete(endpoint) { return api.delete(endpoint).then(r => r.data); }

// ===== In-memory link cache: discordId => panelUserId =====
const linkCache = new Map();

async function resolveLink(discordId) {
  if (linkCache.has(discordId)) return linkCache.get(discordId);
  try {
    const data = await apiGet(`/users?limit=10000`);
    const links = await apiGet('/discord/links');
    const match = links.links?.find(l => l.discord_id === discordId);
    if (match) {
      linkCache.set(discordId, match.panel_user_id);
      return match.panel_user_id;
    }
    return null;
  } catch { return null; }
}

function invalidateCache(discordId) { linkCache.delete(discordId); }

// ===== Permission Check =====
function isAdmin(member, userId) {
  if (config.adminUserIds && config.adminUserIds.includes(userId)) return true;
  if (config.adminRoleId && member.roles.cache.has(config.adminRoleId)) return true;
  return false;
}

// ===== Timer & Formatting =====
const statusEmoji = { running: '🟢', stopped: '🔴', starting: '🟡', stopping: '🟠' };
const statusText = { running: 'Running', stopped: 'Stopped', starting: 'Starting', stopping: 'Stopping' };

function fmtBytes(b) {
  if (!b) return '0 B';
  const s = ['B', 'KB', 'MB', 'GB', 'TB'], i = Math.floor(Math.log(b) / Math.log(1024));
  return (b / Math.pow(1024, i)).toFixed(1) + ' ' + s[i];
}

function fmtUptime(ms) {
  if (!ms) return 'N/A';
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60), d = Math.floor(h / 24);
  return d ? `${d}d ${h % 24}h` : h ? `${h}h ${m % 60}m` : `${m}m ${s % 60}s`;
}

// ===== Embeds =====
function serverEmbed(s) {
  const e = statusEmoji[s.status] || '❓';
  return new EmbedBuilder()
    .setTitle(`${e} ${s.name}`)
    .setColor(s.status === 'running' ? 0x2ecc71 : 0xe74c3c)
    .addFields(
      { name: 'ID', value: `\`${s.id}\``, inline: true },
      { name: 'Status', value: statusText[s.status] || s.status, inline: true },
      { name: 'Type', value: s.server_type || 'N/A', inline: true },
      { name: 'Version', value: s.version || 'N/A', inline: true },
      { name: 'Port', value: String(s.port || 'N/A'), inline: true },
      { name: 'RAM', value: `${s.ram || 0} MB`, inline: true },
      { name: 'CPU', value: `${s.cpu || 0} Core(s)`, inline: true },
      { name: 'Disk', value: `${s.disk || 0} MB`, inline: true },
      { name: 'Node', value: s.node_id ? `\`${s.node_id}\`` : 'Local', inline: true }
    )
    .setFooter({ text: `Created: ${s.created_at || 'N/A'}` })
    .setTimestamp();
}

function serverFullEmbed(s, stats, players, ownerName) {
  const e = statusEmoji[s.status] || '❓';
  const embed = new EmbedBuilder()
    .setTitle(`${e} ${s.name}`)
    .setColor(s.status === 'running' ? 0x2ecc71 : 0xe74c3c)
    .addFields(
      { name: 'ID', value: `\`${s.id}\``, inline: true },
      { name: 'Status', value: statusText[s.status] || s.status, inline: true },
      { name: 'Type', value: s.server_type || 'N/A', inline: true },
      { name: 'Version', value: s.version || 'N/A', inline: true },
      { name: 'Port', value: String(s.port || 'N/A'), inline: true },
      { name: 'RAM', value: `${s.ram || 0} MB`, inline: true },
      { name: 'CPU', value: `${s.cpu || 0} Core(s)`, inline: true },
      { name: 'Disk', value: `${s.disk || 0} MB`, inline: true },
      { name: 'Node', value: s.node_id ? `\`${s.node_id}\`` : 'Local', inline: true }
    )
    .setTimestamp();
  if (ownerName) embed.addFields({ name: 'Owner', value: ownerName, inline: false });
  if (stats) {
    embed.addFields(
      { name: 'CPU Usage', value: stats.cpu ? `${stats.cpu.toFixed(1)}%` : 'N/A', inline: true },
      { name: 'RAM Usage', value: stats.memory ? `${fmtBytes(stats.memory)}` : 'N/A', inline: true },
      { name: 'Uptime', value: fmtUptime(stats.uptime), inline: true }
    );
  }
  if (players && players.length > 0) {
    embed.addFields({ name: `Players (${players.length})`, value: players.map(p => p.name || p.username || p).join(', ').substring(0, 1024), inline: false });
  }
  return embed;
}

function nodeEmbed(n) {
  const e = n.status === 'online' ? '🟢' : '🔴';
  return new EmbedBuilder()
    .setTitle(`${e} ${n.name}`)
    .setColor(n.status === 'online' ? 0x2ecc71 : 0xe74c3c)
    .addFields(
      { name: 'ID', value: `\`${n.id}\``, inline: true },
      { name: 'Status', value: n.status || 'offline', inline: true },
      { name: 'Address', value: `${n.ip_address}:${n.port}`, inline: false },
      { name: 'Memory', value: `${fmtBytes(n.memory_used || 0)} / ${fmtBytes(n.memory_total || 0)}`, inline: true },
      { name: 'Disk', value: `${fmtBytes(n.disk_used || 0)} / ${fmtBytes(n.disk_total || 0)}`, inline: true },
      { name: 'CPU Cores', value: String(n.cpu_cores || 0), inline: true }
    )
    .setFooter({ text: `Updated: ${n.updated_at || 'N/A'}` })
    .setTimestamp();
}

// ===== Commands =====
const cmdDefs = [
  new SlashCommandBuilder().setName('help').setDescription('Show all commands'),

  // Server management
  new SlashCommandBuilder().setName('servers').setDescription('List your servers'),
  new SlashCommandBuilder().setName('server').setDescription('View server details')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),

  // Server control
  ...[['start','Start'],['stop','Stop'],['restart','Restart'],['kill','Force kill']].map(([n,d]) =>
    new SlashCommandBuilder().setName(n).setDescription(`${d} a server`)
      .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true))),
  new SlashCommandBuilder().setName('command').setDescription('Send a console command')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true))
    .addStringOption(o => o.setName('command').setDescription('Command').setRequired(true)),
  new SlashCommandBuilder().setName('console').setDescription('View console output')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  new SlashCommandBuilder().setName('players').setDescription('View online players')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),
  new SlashCommandBuilder().setName('backups').setDescription('List backups')
    .addIntegerOption(o => o.setName('id').setDescription('Server ID').setRequired(true)),

  // User linking
  new SlashCommandBuilder().setName('me').setDescription('Your linked panel account & servers'),
  ...[['link','Link a Discord user to a panel account (admin)'],
     ['unlink','Unlink a Discord user (admin)']].map(([n,d]) =>
    new SlashCommandBuilder().setName(n).setDescription(d)
      .addUserOption(o => o.setName('user').setDescription('Discord user').setRequired(true))
      .addIntegerOption(o => o.setName('panel_id').setDescription('Panel user ID').setRequired(n==='link'))),
  new SlashCommandBuilder().setName('links').setDescription('List all Discord links (admin)'),

  // Nodes (admin)
  new SlashCommandBuilder().setName('nodes').setDescription('List all nodes (admin)'),
  new SlashCommandBuilder().setName('node').setDescription('Node details (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('Node ID').setRequired(true)),
  new SlashCommandBuilder().setName('node-refresh').setDescription('Refresh node stats (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('Node ID').setRequired(true)),

  // Users (admin)
  new SlashCommandBuilder().setName('users').setDescription('List all users (admin)'),
  new SlashCommandBuilder().setName('user').setDescription('User details (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('User ID').setRequired(true)),
  new SlashCommandBuilder().setName('user-create').setDescription('Create a user (admin)')
    .addStringOption(o => o.setName('username').setDescription('Username').setRequired(true))
    .addStringOption(o => o.setName('email').setDescription('Email').setRequired(true))
    .addStringOption(o => o.setName('password').setDescription('Password').setRequired(true))
    .addStringOption(o => o.setName('role').setDescription('Role').addChoices({name:'user',value:'user'},{name:'admin',value:'admin'})),
  new SlashCommandBuilder().setName('user-delete').setDescription('Delete a user (admin)')
    .addIntegerOption(o => o.setName('id').setDescription('User ID').setRequired(true)),

  // Panel
  new SlashCommandBuilder().setName('panel-stats').setDescription('Panel statistics (admin)'),
];

// ===== Handlers =====
async function handleCmd(interaction) {
  const { commandName, options, member, user } = interaction;

  // Resolve linked user (if any)
  let panelUserId = null;
  if (!isAdmin(member, user.id)) {
    panelUserId = await resolveLink(user.id);
  }

  // For user-specific commands, admin gets all; linked user gets their own
  const isAdminUser = isAdmin(member, user.id);
  const effectiveUserId = isAdminUser ? null : panelUserId;

  // Protect admin-only commands
  const adminCmds = ['nodes','node','node-refresh','users','user','user-create','user-delete','panel-stats','links'];
  if (adminCmds.includes(commandName) && !isAdminUser) {
    return interaction.reply({ content: '❌ Admin only.', ephemeral: true });
  }
  const linkCmds = ['link','unlink'];
  if (linkCmds.includes(commandName) && !isAdminUser) {
    return interaction.reply({ content: '❌ Admin only.', ephemeral: true });
  }

  // Block user commands if not linked and not admin
  const userServerCmds = ['servers','server','start','stop','restart','kill','command','console','players','backups'];
  if (userServerCmds.includes(commandName) && !isAdminUser && !panelUserId) {
    return interaction.reply({ content: '❌ You are not linked to any panel account. Ask an admin to use `/link`.', ephemeral: true });
  }

  try {
    switch (commandName) {
      // ==================== HELP ====================
      case 'help': {
        const embed = new EmbedBuilder().setTitle('📖 Panel Bot Commands').setColor(0x3498db)
          .addFields(
            { name: '📋 Server', value:
              '`/servers` — List your servers\n`/server <id>` — Details & controls\n' +
              '`/start|stop|restart|kill <id>` — Control server\n' +
              '`/command <id> <cmd>` — Send command\n`/console <id>` — Console log\n' +
              '`/players <id>` — Online players\n`/backups <id>` — Backups', inline: false },
            { name: '🔗 Linking', value:
              '`/me` — Your linked account\n`/link <@user> <pid>` — Link Discord→Panel (admin)\n' +
              '`/unlink <@user>` — Unlink (admin)\n`/links` — All links (admin)', inline: false },
            { name: '🖧 Nodes (admin)', value: '`/nodes` `/node <id>` `/node-refresh <id>`', inline: false },
            { name: '👥 Users (admin)', value: '`/users` `/user <id>` `/user-create` `/user-delete <id>`', inline: false },
            { name: '📊 Admin', value: '`/panel-stats`', inline: false })
          .setTimestamp();
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // ==================== SERVERS ====================
      case 'servers': {
        await interaction.deferReply();
        const data = isAdminUser ? await apiGet('/servers') : await apiAs('/servers', 'GET', null, panelUserId);
        const servers = data.servers || [];
        if (!servers.length) return interaction.editReply('📭 No servers found.');
        const lines = servers.map(s => {
          const e = statusEmoji[s.status] || '❓';
          return `\`#${s.id}\` ${e} **${s.name}** — ${statusText[s.status] || s.status} (${s.server_type})`;
        });
        const pages = [];
        for (let i = 0; i < lines.length; i += 15) pages.push(lines.slice(i, i + 15).join('\n'));
        const embed = new EmbedBuilder().setTitle(`📋 Servers (${servers.length})`).setColor(0x3498db).setDescription(pages[0]).setTimestamp();
        if (pages.length > 1) embed.setFooter({ text: `Page 1/${pages.length}` });
        const msg = await interaction.editReply({ embeds: [embed] });
        if (pages.length > 1) paginate(interaction, msg, embed, pages);
        break;
      }

      case 'server': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        const data = isAdminUser ? await apiGet(`/servers/${id}`) : await apiAs(`/servers/${id}`, 'GET', null, panelUserId);
        const embed = serverFullEmbed(data.server, data.stats, data.players, data.server?.owner_name);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`act_start_${id}`).setLabel('▶ Start').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`act_stop_${id}`).setLabel('⏹ Stop').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId(`act_restart_${id}`).setLabel('🔄 Restart').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`act_refresh_${id}`).setLabel('🔄 Refresh').setStyle(ButtonStyle.Primary)
        );
        const msg = await interaction.editReply({ embeds: [embed], components: [row] });
        const coll = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 30000 });
        coll.on('collect', async (i) => {
          if (i.user.id !== user.id) return i.reply({ content: 'Not your interaction', ephemeral: true });
          await i.deferUpdate();
          const [, action, sid] = i.customId.split('_');
          try {
            if (action === 'refresh') {
              const fresh = isAdminUser ? await apiGet(`/servers/${sid}`) : await apiAs(`/servers/${sid}`, 'GET', null, panelUserId);
              await i.editReply({ embeds: [serverFullEmbed(fresh.server, fresh.stats, fresh.players)] });
            } else {
              const actor = isAdminUser ? null : panelUserId;
              await (actor ? apiAs(`/servers/${sid}/${action}`, 'POST', {}, actor) : apiPost(`/servers/${sid}/${action}`));
              await new Promise(r => setTimeout(r, 1000));
              const fresh = isAdminUser ? await apiGet(`/servers/${sid}`) : await apiAs(`/servers/${sid}`, 'GET', null, panelUserId);
              await i.editReply({ embeds: [serverFullEmbed(fresh.server, fresh.stats, fresh.players)] });
            }
          } catch (e) {
            await i.followUp({ content: `❌ ${e.response?.data?.error || e.message}`, ephemeral: true });
          }
        });
        coll.on('end', () => msg.edit({ components: [] }).catch(() => {}));
        break;
      }

      // ==================== SERVER CONTROL ====================
      case 'start': case 'stop': case 'restart': case 'kill': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        try {
          const actor = isAdminUser ? null : panelUserId;
          const result = actor
            ? await apiAs(`/servers/${id}/${commandName}`, 'POST', {}, actor)
            : await apiPost(`/servers/${id}/${commandName}`);
          await interaction.editReply(`✅ **Server #${id}** — ${result.message || commandName}`);
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'command': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        const cmd = options.getString('command');
        try {
          const actor = isAdminUser ? null : panelUserId;
          await (actor ? apiAs(`/servers/${id}/command`, 'POST', { command: cmd }, actor) : apiPost(`/servers/${id}/command`, { command: cmd }));
          await interaction.editReply(`✅ Command sent to **#${id}**: \`${cmd}\``);
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'console': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        try {
          const data = isAdminUser ? await apiGet(`/servers/${id}/console`) : await apiAs(`/servers/${id}/console`, 'GET', null, panelUserId);
          const log = data.logContent || '';
          const lines = log.split('\n').filter(l => l.trim()).slice(-30).join('\n');
          const truncated = lines.length > 1900 ? lines.substring(lines.length - 1900) : lines || 'No log output.';
          const embed = new EmbedBuilder()
            .setTitle(`📜 Console — Server #${id}`).setColor(0x2c3e50)
            .setDescription(`\`\`\`ansi\n${truncated}\n\`\`\``).setTimestamp();
          await interaction.editReply({ embeds: [embed] });
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'players': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        try {
          const data = isAdminUser ? await apiGet(`/servers/${id}/players`) : await apiAs(`/servers/${id}/players`, 'GET', null, panelUserId);
          const p = data.online || [];
          const embed = new EmbedBuilder()
            .setTitle(`👥 Players — Server #${id}`).setColor(0x3498db)
            .addFields(
              { name: 'Online', value: `${p.length}`, inline: true },
              { name: 'Whitelisted', value: String(data.whitelist?.length || 0), inline: true },
              { name: 'OPs', value: String(data.ops?.length || 0), inline: true })
            .setTimestamp();
          if (p.length) embed.addFields({ name: 'Players', value: p.map(x => x.name || x.username || x).join(', ').substring(0, 1024) });
          await interaction.editReply({ embeds: [embed] });
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'backups': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        try {
          const data = isAdminUser ? await apiGet(`/servers/${id}/backups`) : await apiAs(`/servers/${id}/backups`, 'GET', null, panelUserId);
          const b = data.backups || [];
          if (!b.length) return interaction.editReply(`📦 No backups for **Server #${id}**.`);
          const embed = new EmbedBuilder()
            .setTitle(`📦 Backups — Server #${id} (${b.length})`).setColor(0x9b59b6)
            .setDescription(b.map((x,i) => `\`#${x.id}\` **${x.name}** — ${x.size ? fmtBytes(parseInt(x.size)) : 'N/A'} (${x.created_at || 'N/A'})`).join('\n'))
            .setTimestamp();
          await interaction.editReply({ embeds: [embed] });
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      // ==================== LINKING ====================
      case 'me': {
        await interaction.deferReply({ ephemeral: true });
        const data = isAdminUser ? await apiGet('/discord/me') : null;
        const linkedData = !isAdminUser ? await apiAs('/discord/me', 'GET', null, panelUserId) : data;
        if (!linkedData || !linkedData.linked) {
          return interaction.editReply('❌ You are not linked to any panel account. Ask an admin to use `/link`.');
        }
        const srv = await apiAs('/servers', 'GET', null, linkedData.panel_user_id);
        const embed = new EmbedBuilder()
          .setTitle(`🔗 Panel Account — ${linkedData.username}`)
          .setColor(0x2ecc71)
          .addFields(
            { name: 'Panel ID', value: `\`${linkedData.panel_user_id}\``, inline: true },
            { name: 'Username', value: linkedData.username, inline: true },
            { name: 'Email', value: linkedData.email || 'N/A', inline: true },
            { name: 'Role', value: linkedData.role || 'user', inline: true },
            { name: 'Status', value: linkedData.status || 'active', inline: true },
            { name: 'Servers', value: String(srv.servers?.length || 0), inline: true })
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case 'link': {
        const target = options.getUser('user');
        const panelId = options.getInteger('panel_id');
        await interaction.deferReply({ ephemeral: true });
        try {
          const result = await apiPost('/discord/link', { discord_id: target.id, panel_user_id: panelId });
          invalidateCache(target.id);
          await interaction.editReply(`✅ Linked <@${target.id}> → **${result.panel_username}** (ID: \`${result.panel_user_id}\`)`);
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'unlink': {
        const target = options.getUser('user');
        await interaction.deferReply({ ephemeral: true });
        try {
          await apiDelete(`/discord/link/${target.id}`);
          invalidateCache(target.id);
          await interaction.editReply(`✅ Unlinked <@${target.id}> from panel.`);
        } catch (e) {
          await interaction.editReply({ content: `❌ ${e.response?.data?.error || e.message}` });
        }
        break;
      }

      case 'links': {
        await interaction.deferReply();
        const data = await apiGet('/discord/links');
        const links = data.links || [];
        if (!links.length) return interaction.editReply('No Discord links configured.');
        const embed = new EmbedBuilder()
          .setTitle(`🔗 Discord Links (${links.length})`).setColor(0x9b59b6)
          .setDescription(links.map(l => `<@${l.discord_id}> → **${l.panel_username}** (ID: \`${l.panel_user_id}\`)`).join('\n'))
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      // ==================== NODES (admin) ====================
      case 'nodes': {
        await interaction.deferReply();
        const data = await apiGet('/nodes');
        const nodes = data.nodes || [];
        if (!nodes.length) return interaction.editReply('No nodes found.');
        const embed = new EmbedBuilder()
          .setTitle(`🖥 Nodes (${nodes.length})`).setColor(0x2ecc71)
          .setDescription(nodes.map(n => `${n.status === 'online' ? '🟢' : '🔴'} \`#${n.id}\` **${n.name}** — ${n.ip_address}:${n.port}`).join('\n'))
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case 'node': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        const data = await apiGet(`/nodes/${id}`);
        const embed = nodeEmbed(data.node);
        if (data.serverCount !== undefined) embed.addFields({ name: 'Servers', value: String(data.serverCount), inline: true });
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case 'node-refresh': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        try {
          await apiPost(`/nodes/${id}/refresh`);
          const data = await apiGet(`/nodes/${id}`);
          await interaction.editReply({ embeds: [nodeEmbed(data.node)] });
        } catch (e) {
          await interaction.editReply(`❌ ${e.response?.data?.error || e.message}`);
        }
        break;
      }

      // ==================== USERS (admin) ====================
      case 'users': {
        await interaction.deferReply();
        const data = await apiGet('/users');
        const users = data.users || [];
        if (!users.length) return interaction.editReply('No users found.');
        const embed = new EmbedBuilder()
          .setTitle(`👥 Users (${users.length})`).setColor(0x3498db)
          .setDescription(users.map(u => `${u.status === 'active' ? '🟢' : '🔴'} \`#${u.id}\` **${u.username}** ${u.role === 'admin' ? '👑' : ''} — ${u.email}`).join('\n'))
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case 'user': {
        await interaction.deferReply();
        const id = options.getInteger('id');
        const data = await apiGet(`/users/${id}`);
        const u = data.user;
        const e = u.status === 'active' ? '🟢' : '🔴';
        const embed = new EmbedBuilder()
          .setTitle(`${e} ${u.username}`).setColor(u.role === 'admin' ? 0xf1c40f : 0x3498db)
          .addFields(
            { name: 'ID', value: `\`${u.id}\``, inline: true },
            { name: 'Role', value: u.role || 'user', inline: true },
            { name: 'Status', value: u.status || 'active', inline: true },
            { name: 'Email', value: u.email || 'N/A', inline: false },
            { name: 'Created', value: u.created_at || 'N/A', inline: true },
            { name: 'Servers', value: String(data.serverCount || 0), inline: true })
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case 'user-create': {
        await interaction.deferReply({ ephemeral: true });
        try {
          const r = await apiPost('/users', {
            username: options.getString('username'),
            email: options.getString('email'),
            password: options.getString('password'),
            role: options.getString('role') || 'user'
          });
          await interaction.editReply(`✅ User **${r.username}** created (ID: \`${r.userId}\`, role: ${r.role})`);
        } catch (e) {
          await interaction.editReply(`❌ ${e.response?.data?.error || e.message}`);
        }
        break;
      }

      case 'user-delete': {
        await interaction.deferReply({ ephemeral: true });
        try {
          await apiDelete(`/users/${options.getInteger('id')}`);
          await interaction.editReply(`✅ User #${options.getInteger('id')} deleted.`);
        } catch (e) {
          await interaction.editReply(`❌ ${e.response?.data?.error || e.message}`);
        }
        break;
      }

      // ==================== PANEL STATS ====================
      case 'panel-stats': {
        await interaction.deferReply();
        const data = await apiGet('/stats');
        const s = data.stats;
        const embed = new EmbedBuilder()
          .setTitle('📊 Panel Statistics').setColor(0x2ecc71)
          .addFields(
            { name: '🖥 Servers', value: `${s.runningServers} running / ${s.totalServers} total`, inline: true },
            { name: '👥 Users', value: String(s.totalUsers), inline: true },
            { name: '🖧 Nodes', value: `${s.onlineNodes} online / ${s.totalNodes} total`, inline: true },
            { name: '📄 Invoices', value: String(s.totalInvoices), inline: true },
            { name: '💰 Revenue', value: `$${Number(s.totalRevenue || 0).toFixed(2)}`, inline: true })
          .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        break;
      }
    }
  } catch (error) {
    const msg = error.response?.data?.error || error.message || 'Unknown error';
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: `❌ ${msg}`, ephemeral: true }).catch(() => {});
    } else {
      await interaction.editReply({ content: `❌ ${msg}` }).catch(() => {});
    }
  }
}

// ===== Pagination helper =====
function paginate(interaction, msg, baseEmbed, pages) {
  let page = 0;
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pg_prev').setLabel('◀').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('pg_next').setLabel('▶').setStyle(ButtonStyle.Primary)
  );
  msg.edit({ components: [row] });
  const coll = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
  coll.on('collect', async (i) => {
    if (i.user.id !== interaction.user.id) return i.reply({ content: 'Not your interaction', ephemeral: true });
    page = i.customId === 'pg_next' ? Math.min(page + 1, pages.length - 1) : Math.max(page - 1, 0);
    const e = EmbedBuilder.from(baseEmbed).setDescription(pages[page]).setFooter({ text: `Page ${page + 1}/${pages.length}` });
    await i.update({ embeds: [e] });
  });
  coll.on('end', () => msg.edit({ components: [] }).catch(() => {}));
}

// ===== Client =====
client.once('ready', () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  console.log(`🔗 Panel: ${config.panelUrl}`);
  console.log(`📡 ${client.guilds.cache.size} guild(s)`);
});

client.on('interactionCreate', async (i) => {
  if (i.isChatInputCommand()) await handleCmd(i);
});

client.login(config.token).catch(err => {
  console.error('❌ Login failed:', err.message);
  process.exit(1);
});
