#!/bin/bash

# Minecraft Panel Node Agent Setup Script
# For Debian/Ubuntu/CentOS/Rocky Linux

set -e

echo "=========================================="
echo "  Minecraft Panel Node Agent Setup"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]
  then echo "Please run as root"
  exit
fi

# Variables
INSTALL_DIR="/opt/minecraft-panel-node"
SERVICE_NAME="node-agent"

# Step 1: Check if Node.js is installed
if ! command -v node &> /dev/null
then
    echo "Node.js is not installed. Installing Node.js..."
    if command -v apt &> /dev/null
    then
        # Debian/Ubuntu
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
        apt install -y nodejs
    elif command -v dnf &> /dev/null
    then
        # CentOS/Rocky/Alma
        dnf module enable -y nodejs:20
        dnf install -y nodejs
    elif command -v yum &> /dev/null
    then
        # Older CentOS
        curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
        yum install -y nodejs
    else
        echo "Unsupported OS! Please install Node.js 18+ manually"
        exit 1
    fi
fi

echo "✓ Node.js version: $(node -v)"
echo "✓ npm version: $(npm -v)"

# Step 2: Create installation directory
echo ""
echo "Creating installation directory at $INSTALL_DIR..."
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Step 3: Copy required files
echo ""
echo "Copying node agent files..."
# Note: In real usage, you'd download from repo or copy manually
# For this example, we'll create basic files

cat > node-agent.js << 'EOF'
const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const pidusage = require('pidusage');

// Load environment variables
let envConfig = {};
try {
    const envPath = path.join(__dirname, '.agent-env');
    if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        envContent.split('\n').forEach(line => {
            const [key, value] = line.split('=');
            if (key && value) {
                envConfig[key.trim()] = value.trim();
            }
        });
    }
} catch (e) {
    console.log('No .agent-env file found, using defaults');
}

const app = express();
const PORT = process.env.AGENT_PORT || envConfig.AGENT_PORT || 3001;
const API_KEY = process.env.AGENT_API_KEY || envConfig.AGENT_API_KEY || null;
const DATA_DIR = path.join(__dirname, 'node-data');
const SERVERS_DIR = path.join(DATA_DIR, 'servers');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

app.use(express.json());

const validateApiKey = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    if (!API_KEY) {
        console.warn('Warning: No API key configured! This is insecure.');
        return next();
    }
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
};

const serverProcesses = {};
const resolveServerPath = (serverId) => path.join(SERVERS_DIR, serverId.toString());

app.get('/api/stats', validateApiKey, (req, res) => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    let diskTotal = 1000000;
    let diskUsed = 500000;
    
    res.json({
        memory_total: Math.round(totalMem / (1024 * 1024)),
        memory_used: Math.round(usedMem / (1024 * 1024)),
        disk_total: diskTotal,
        disk_used: diskUsed,
        cpu_cores: os.cpus().length,
        uptime: os.uptime()
    });
});

app.get('/api/servers', validateApiKey, (req, res) => {
    const servers = [];
    if (fs.existsSync(SERVERS_DIR)) {
        const dirs = fs.readdirSync(SERVERS_DIR);
        dirs.forEach(dir => {
            servers.push({ id: dir, status: 'stopped' });
        });
    }
    res.json(servers);
});

app.post('/api/servers/:id/create', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    if (!fs.existsSync(serverDir)) {
        fs.mkdirSync(serverDir, { recursive: true });
    }
    res.json({ success: true });
});

app.post('/api/servers/:id/start', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    
    if (serverProcesses[serverId]) {
        return res.json({ success: false, error: 'Server already running' });
    }
    
    const cmd = process.platform === 'win32' ? 'ping' : 'ping';
    const args = process.platform === 'win32' ? ['localhost', '-t'] : ['localhost', '-c', '10000'];
    
    const process = spawn(cmd, args, { cwd: serverDir });
    serverProcesses[serverId] = process;
    res.json({ success: true });
});

app.post('/api/servers/:id/stop', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    if (serverProcesses[serverId]) {
        serverProcesses[serverId].kill('SIGTERM');
        delete serverProcesses[serverId];
    }
    res.json({ success: true });
});

app.get('/api/servers/:id/status', validateApiKey, async (req, res) => {
    const serverId = req.params.id;
    const isRunning = !!serverProcesses[serverId];
    let stats = { status: 'stopped' };
    
    if (isRunning && serverProcesses[serverId].pid) {
        try {
            const usage = await pidusage(serverProcesses[serverId].pid);
            stats = {
                status: 'running',
                cpu: usage.cpu,
                memory: usage.memory / (1024 * 1024)
            };
        } catch (e) {
            stats.status = 'stopped';
            delete serverProcesses[serverId];
        }
    }
    
    res.json(stats);
});

app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log('='.repeat(60));
    console.log('  Node Agent Started');
    console.log('='.repeat(60));
    console.log(`  Port: ${PORT}`);
    console.log(`  Data Directory: ${DATA_DIR}`);
    if (API_KEY) {
        console.log('  API Key Configured');
    } else {
        console.warn('  WARNING: No API Key configured! Insecure.');
    }
    console.log('='.repeat(60));
    console.log('');
});
EOF

# Create package.json
cat > package.json << 'EOF'
{
  "name": "minecraft-panel-node-agent",
  "version": "1.0.0",
  "description": "Node agent for Minecraft panel multi-node system",
  "main": "node-agent.js",
  "dependencies": {
    "express": "^4.18.2",
    "pidusage": "^4.0.1"
  }
}
EOF

# Step 4: Install dependencies
echo ""
echo "Installing dependencies..."
npm install

# Step 5: Create example config
if [ ! -f .agent-env ]; then
    cat > .agent-env << 'EOF'
AGENT_PORT=3001
AGENT_API_KEY=your-api-key-here
EOF
    echo ""
    echo "⚠️  IMPORTANT: Edit $INSTALL_DIR/.agent-env and set your API key!"
fi

# Step 6: Install systemd service
echo ""
echo "Setting up systemd service..."
cat > /etc/systemd/system/node-agent.service << 'EOF'
[Unit]
Description=Minecraft Panel Node Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/minecraft-panel-node
ExecStart=/usr/bin/node node-agent.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload

# Step 7: Firewall setup
echo ""
echo "Setting up firewall..."
if command -v ufw &> /dev/null
then
    ufw allow 3001/tcp comment "Minecraft Panel Node Agent"
elif command -v firewall-cmd &> /dev/null
then
    firewall-cmd --permanent --add-port=3001/tcp
    firewall-cmd --reload
fi

echo ""
echo "=========================================="
echo "  Setup Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Edit $INSTALL_DIR/.agent-env to set your API key"
echo "2. Start the service: systemctl start node-agent"
echo "3. Enable on boot: systemctl enable node-agent"
echo "4. Check status: systemctl status node-agent"
echo "5. View logs: journalctl -u node-agent -f"
echo ""
echo "Then add the node in your panel's admin area!"
echo ""
