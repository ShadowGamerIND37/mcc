const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { spawn, exec, execSync } = require('child_process');
const pidusage = require('pidusage');
const { promisify } = require('util');
const execAsync = promisify(exec);
const axios = require('axios');
const unzipper = require('unzipper');
const archiver = require('archiver');
const multer = require('multer');
const sanitize = require('sanitize-filename');
const http = require('http');
const WebSocket = require('ws');

// Load environment variables
let envConfig = {};
try {
    const envPath = path.join(__dirname, '.agent-env');
    if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        envContent.split('\n').forEach(line => {
            const [key, value] = line.split('=');
            if (key && value) {
                envConfig[key.trim()] = value.trim();
            }
        });
    }
} catch (e) {
    console.log('No .agent-env file found, using defaults');
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = process.env.AGENT_PORT || envConfig.AGENT_PORT || 3001;
const API_KEY = process.env.AGENT_API_KEY || envConfig.AGENT_API_KEY || null;
const DATA_DIR = path.join(__dirname, 'node-data');
const SERVERS_DIR = path.join(DATA_DIR, 'servers');
const PROCESSES_FILE = path.join(DATA_DIR, 'server-processes.json');

// Ensure directories exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

// Global state
let serverProcesses = {};
let serverConsoles = {}; // Store console log buffers
const consoleWebSocketClients = {}; // Store WS clients per server
// Live ChildProcess handles, keyed by serverId. Kept separate from serverProcesses
// because serverProcesses gets JSON-persisted to disk (so a ChildProcess object,
// which has circular references, can never live there) and because handles for
// processes started before an agent restart can't be recovered anyway.
const liveProcessHandles = {};

// Load saved processes
function loadSavedProcesses() {
    try {
        if (fs.existsSync(PROCESSES_FILE)) {
            const saved = JSON.parse(fs.readFileSync(PROCESSES_FILE, 'utf8'));
            for (const id of Object.keys(saved)) {
                const procInfo = saved[id];
                if (procInfo && procInfo.pid) {
                    try {
                        if (process.platform === 'win32') {
                            execSync(`tasklist /FI "PID eq ${procInfo.pid}"`, { stdio: 'ignore' });
                            serverProcesses[id] = procInfo;
                        } else {
                            process.kill(procInfo.pid, 0);
                            serverProcesses[id] = procInfo;
                        }
                    } catch (err) {
                        console.log(`Process ${procInfo.pid} for server ${id} not running`);
                    }
                }
            }
            saveProcesses();
            console.log(`Loaded ${Object.keys(serverProcesses).length} saved server process(es)`);
        }
    } catch (e) {
        console.error('Error loading saved processes:', e.message);
    }
}

function saveProcesses() {
    try {
        fs.writeFileSync(PROCESSES_FILE, JSON.stringify(serverProcesses, null, 2));
    } catch (e) {
        console.error('Error saving processes:', e.message);
    }
}

// Helper: disk usage
async function getDiskUsage() {
    let total = 1000000;
    let used = 500000;
    try {
        if (process.platform !== 'win32') {
            const { stdout } = await execAsync('df -P -B 1M /');
            const lines = stdout.trim().split('\n');
            if (lines.length > 1) {
                const parts = lines[1].trim().split(/\s+/);
                if (parts.length >= 6) {
                    total = parseInt(parts[1]);
                    used = parseInt(parts[2]);
                }
            }
        }
    } catch (e) {
        console.error('Disk usage check failed:', e.message);
    }
    return { total, used };
}

// Helper: move a file, tolerating EXDEV (the temp upload location and the final
// destination living on different mounted filesystems/devices). fs.rename() is a
// thin wrapper around the rename(2) syscall, which the OS refuses to do across
// devices - copy+delete is the standard fallback for that case.
function safeMoveSync(src, dest) {
    try {
        fs.renameSync(src, dest);
    } catch (err) {
        if (err.code !== 'EXDEV') throw err;
        fs.copyFileSync(src, dest);
        fs.unlinkSync(src);
    }
}

// Helper: server path
// IMPORTANT: this must reject any input that resolves outside the server's own
// directory (e.g. path: '../../../etc/passwd'). path.join() alone does NOT do
// this - it happily collapses '..' segments and walks out of SERVERS_DIR, which
// previously let any authenticated request read/write/delete arbitrary files
// on the node's filesystem.
const resolveServerPath = (serverId, file = '') => {
    const base = path.resolve(SERVERS_DIR, serverId.toString());
    const full = path.resolve(path.join(base, (file || '').replace(/^\//, '')));
    if (full !== base && !full.startsWith(base + path.sep)) {
        throw new Error('Invalid path');
    }
    return full;
};

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Download server jar
async function downloadServerJar(serverType, version, dir) {
    let url;
    let actualVersion = version;
    try {
        console.log(`Downloading ${serverType} ${version}...`);
        if (version === 'latest') {
            if (serverType === 'vanilla') {
                const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
                actualVersion = manifestRes.data.latest.release;
            } else if (serverType === 'paper') {
                const res = await axios.get('https://api.papermc.io/v2/projects/paper');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'purpur') {
                const res = await axios.get('https://api.purpurmc.org/v2/purpur');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            }
        }
        if (serverType === 'vanilla') {
            const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
            const ver = manifestRes.data.versions.find(v => v.id === actualVersion);
            if (!ver) throw new Error(`Vanilla version ${actualVersion} not found`);
            const verJsonRes = await axios.get(ver.url);
            url = verJsonRes.data.downloads.server.url;
        } else if (serverType === 'paper') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds/${build.build}/downloads/paper-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'purpur') {
            const latestBuildRes = await axios.get(`https://api.purpurmc.org/v2/purpur/${actualVersion}/latest`);
            const build = latestBuildRes.data.build;
            url = `https://api.purpurmc.org/v2/purpur/${actualVersion}/${build}/download`;
        } else if (serverType === 'bedrock') {
            if (process.platform === 'win32') {
                url = 'https://www.minecraft.net/bedrockdedicatedserver/bin-win/bedrock-server-1.26.14.1.zip';
            } else {
                url = 'https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-1.26.14.1.zip';
            }
        }
        const serverJar = path.join(dir, 'server.jar');
        let downloadFile = serverJar;
        if (serverType === 'bedrock') downloadFile = path.join(dir, 'bedrock-server.zip');
        
        const response = await axios({ method: 'GET', url: url, responseType: 'stream', timeout: 600000 });
        await new Promise((resolve, reject) => {
            const writer = fs.createWriteStream(downloadFile);
            response.data.pipe(writer);
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
        
        if (serverType === 'bedrock') {
            console.log('Extracting Bedrock server files');
            await fs.createReadStream(downloadFile).pipe(unzipper.Extract({ path: dir })).promise();
            if (process.platform !== 'win32') {
                const bedrockExec = path.join(dir, 'bedrock_server');
                try { fs.chmodSync(bedrockExec, '755'); } catch(e) {}
            }
            fs.unlinkSync(downloadFile);
        }
        console.log('Download complete');
        return { path: serverJar, version: actualVersion };
    } catch (err) {
        console.error('Download failed:', err.message);
        throw err;
    }
}

const serverConfigs = {};

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, x-api-key');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});
app.use(express.json({ limit: '50mb' }));

// Validate API key middleware
const validateApiKey = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    if (!API_KEY) {
        console.warn('Warning: No API Key configured!');
        return next();
    }
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
};

// Health
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Stats
app.get('/api/stats', validateApiKey, async (req, res) => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const diskUsage = await getDiskUsage();
    res.json({
        memory_total: Math.round(totalMem / (1024 * 1024)),
        memory_used: Math.round(usedMem / (1024 * 1024)),
        disk_total: diskUsage.total,
        disk_used: diskUsage.used,
        cpu_cores: os.cpus().length,
        uptime: os.uptime(),
        hostname: os.hostname(),
        platform: os.platform(),
        arch: os.arch()
    });
});

// List servers on node
app.get('/api/servers', validateApiKey, (req, res) => {
    const servers = [];
    if (fs.existsSync(SERVERS_DIR)) {
        const dirs = fs.readdirSync(SERVERS_DIR);
        dirs.forEach(dir => servers.push({ id: dir, status: serverProcesses[dir] ? 'running' : 'stopped' }));
    }
    res.json(servers);
});

// Create server directory
app.post('/api/servers/:id/create', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    if (!fs.existsSync(serverDir)) {
        fs.mkdirSync(serverDir, { recursive: true });
    }
    if (req.body.config) {
        serverConfigs[serverId] = req.body.config;
    }
    res.json({ success: true });
});

// ================== FILE MANAGEMENT ==================

// List files
app.get('/api/servers/:id/files/list', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const currentPath = req.query.path || '/';
        const dirPath = resolveServerPath(serverId, currentPath);
        if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
        
        const files = fs.readdirSync(dirPath, { withFileTypes: true }).map(dirent => {
            const full = path.join(dirPath, dirent.name);
            const relativePath = currentPath === '/' ? `/${dirent.name}` : `${currentPath}/${dirent.name}`;
            let stats;
            try { stats = fs.statSync(full); } catch { stats = {}; }
            
            return {
                name: dirent.name,
                path: relativePath,
                isDirectory: dirent.isDirectory(),
                size: dirent.isDirectory() ? '-' : formatFileSize(stats.size || 0),
                modified: stats.mtime ? stats.mtime.toLocaleString() : null
            };
        });
        res.json({ success: true, files, currentPath });
    } catch (e) {
        console.error('File list error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// View file content
app.get('/api/servers/:id/files/view', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const filePath = req.query.path;
        if (!filePath) return res.status(400).json({ error: 'Path is required' });
        
        const fullPath = resolveServerPath(serverId, filePath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'File not found' });
        
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) return res.status(400).json({ error: 'Cannot view directory' });
        
        // Text is the default (config files, logs, etc.), but binary files (icons,
        // jars, etc.) need base64 - reading them as utf8 would corrupt the bytes.
        if (req.query.binary === 'true') {
            const content = fs.readFileSync(fullPath).toString('base64');
            return res.json({ success: true, content, name: path.basename(filePath), isBinary: true });
        }
        const content = fs.readFileSync(fullPath, 'utf8');
        res.json({ success: true, content, name: path.basename(filePath) });
    } catch (e) {
        console.error('File view error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Download file
app.get('/api/servers/:id/files/download', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const filePath = req.query.path;
        if (!filePath) return res.status(400).send('Path required');
        
        const fullPath = resolveServerPath(serverId, filePath);
        if (!fs.existsSync(fullPath)) return res.status(404).send('Not found');
        res.download(fullPath);
    } catch (e) {
        res.status(500).send('Download failed: ' + e.message);
    }
});

// Save file content
app.post('/api/servers/:id/files/save', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: filePath, content, isBinary } = req.body;
        if (!filePath || content === undefined) return res.status(400).json({ error: 'Path and content required' });
        
        const fullPath = resolveServerPath(serverId, filePath);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        
        if (isBinary) {
            // Decode base64 and write as binary
            const buffer = Buffer.from(content, 'base64');
            fs.writeFileSync(fullPath, buffer);
        } else {
            // Write as UTF-8 text
            fs.writeFileSync(fullPath, content, 'utf8');
        }
        
        res.json({ success: true });
    } catch (e) {
        console.error('File save error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Rename file/folder
app.post('/api/servers/:id/files/rename', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { oldPath, newName } = req.body;
        if (!oldPath || !newName) return res.status(400).json({ error: 'Required params missing' });
        
        const oldFull = resolveServerPath(serverId, oldPath);
        const sanitizedNewName = sanitize(newName);
        if (!sanitizedNewName) return res.status(400).json({ error: 'Invalid new name' });
        const newFull = path.join(path.dirname(oldFull), sanitizedNewName);
        
        if (fs.existsSync(newFull)) return res.status(409).json({ error: 'Already exists' });
        
        fs.renameSync(oldFull, newFull);
        res.json({ success: true });
    } catch (e) {
        console.error('Rename error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Delete file/folder
app.post('/api/servers/:id/files/delete', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: filePath } = req.body;
        if (!filePath) return res.status(400).json({ error: 'Path required' });
        
        const fullPath = resolveServerPath(serverId, filePath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'Not found' });
        
        fs.rmSync(fullPath, { recursive: true, force: true });
        res.json({ success: true });
    } catch (e) {
        console.error('Delete error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Create folder
app.post('/api/servers/:id/files/create-folder', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: dirPath, name } = req.body;
        const newDir = resolveServerPath(serverId, path.join(dirPath || '/', name));
        
        if (!fs.existsSync(newDir)) {
            fs.mkdirSync(newDir, { recursive: true });
        }
        res.json({ success: true });
    } catch (e) {
        console.error('Folder create error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Create file
app.post('/api/servers/:id/files/create', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: filePath, name } = req.body;
        const newFile = resolveServerPath(serverId, path.join(filePath || '/', name));
        
        if (fs.existsSync(newFile)) return res.status(409).json({ error: 'File already exists' });
        
        fs.writeFileSync(newFile, '', 'utf8');
        res.json({ success: true });
    } catch (e) {
        console.error('File create error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Zip a single file/folder in place
app.post('/api/servers/:id/files/zip', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });

        const fullPath = resolveServerPath(serverId, targetPath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'Not found' });
        if (path.extname(fullPath) === '.zip') {
            return res.status(400).json({ error: 'Target is already a zip file' });
        }

        const zipFullPath = path.join(path.dirname(fullPath), path.basename(fullPath) + '.zip');
        if (fs.existsSync(zipFullPath)) return res.status(409).json({ error: 'Zip file already exists' });

        const output = fs.createWriteStream(zipFullPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        let responseSent = false;

        archive.on('error', (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('Zip archive error:', err);
            res.status(500).json({ success: false, error: err.message });
        });

        output.on('close', () => {
            if (responseSent) return;
            responseSent = true;
            const relativeZipPath = path.relative(resolveServerPath(serverId, '/'), zipFullPath);
            res.json({ success: true, zipPath: relativeZipPath });
        });

        archive.pipe(output);
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
            archive.directory(fullPath, false);
        } else {
            archive.file(fullPath, { name: path.basename(fullPath) });
        }
        archive.finalize();
    } catch (e) {
        console.error('Zip error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Zip multiple files/folders into one new archive
app.post('/api/servers/:id/files/bulk-zip', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const { paths, zipName } = req.body;
        if (!paths || !Array.isArray(paths) || paths.length === 0) {
            return res.status(400).json({ error: 'Paths array is required' });
        }
        const sanitizedZipName = sanitize(zipName || '');
        if (!sanitizedZipName) return res.status(400).json({ error: 'Invalid zip name' });

        const serverDir = resolveServerPath(serverId);
        const zipFullPath = path.join(serverDir, sanitizedZipName);
        if (fs.existsSync(zipFullPath)) return res.status(409).json({ error: 'Zip file already exists' });

        const output = fs.createWriteStream(zipFullPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        let responseSent = false;

        archive.on('error', (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('Bulk zip archive error:', err);
            res.status(500).json({ success: false, error: err.message });
        });

        output.on('close', () => {
            if (responseSent) return;
            responseSent = true;
            res.json({ success: true, zipPath: sanitizedZipName });
        });

        archive.pipe(output);
        for (const targetPath of paths) {
            let fullPath;
            try {
                fullPath = resolveServerPath(serverId, targetPath);
            } catch (e) {
                continue; // skip anything that would resolve outside the server dir
            }
            if (fs.existsSync(fullPath)) {
                const stats = fs.statSync(fullPath);
                const baseName = path.basename(fullPath);
                if (stats.isDirectory()) {
                    archive.directory(fullPath, baseName);
                } else {
                    archive.file(fullPath, { name: baseName });
                }
            }
        }
        archive.finalize();
    } catch (e) {
        console.error('Bulk zip error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Extract a zip file in place
app.post('/api/servers/:id/files/unzip', validateApiKey, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });

        const fullPath = resolveServerPath(serverId, targetPath);
        if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'Not found' });
        if (path.extname(fullPath) !== '.zip') return res.status(400).json({ error: 'Not a zip file' });

        const extractDir = path.dirname(fullPath);
        await new Promise((resolve, reject) => {
            fs.createReadStream(fullPath)
                .pipe(unzipper.Extract({ path: extractDir }))
                .on('close', resolve)
                .on('error', reject);
        });
        res.json({ success: true });
    } catch (e) {
        console.error('Unzip error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Upload a file into a server directory (multipart/form-data: field "file", body field "path")
const agentUpload = multer({ dest: path.join(os.tmpdir(), 'agent-uploads') });
app.post('/api/servers/:id/files/upload', validateApiKey, agentUpload.single('file'), (req, res) => {
    try {
        const serverId = req.params.id;
        if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

        const targetDir = resolveServerPath(serverId, req.body.path || '/');
        if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

        const destPath = path.join(targetDir, sanitize(req.file.originalname));
        if (fs.existsSync(destPath)) {
            fs.unlinkSync(req.file.path);
            return res.status(409).json({ error: 'File already exists' });
        }
        safeMoveSync(req.file.path, destPath);
        res.json({ success: true });
    } catch (e) {
        console.error('Upload error:', e);
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        res.status(500).json({ success: false, error: e.message });
    }
});

// List plugin/mod jars in a directory with extracted metadata (plugin.yml, paper-plugin.yml,
// bungee.yml, fabric.mod.json, or MANIFEST.MF, whichever is found first). Used for both the
// plugins page (dir=plugins) and the mods page (dir=mods) so jar metadata can be read on the
// node itself instead of transferring every jar back to the panel just to inspect it.
app.get('/api/servers/:id/jars', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const dirName = req.query.dir === 'mods' ? 'mods' : 'plugins';
        const dirPath = resolveServerPath(serverId, dirName);
        if (!fs.existsSync(dirPath)) return res.json({ success: true, jars: [] });

        const AdmZip = require('adm-zip');
        const yaml = require('js-yaml');
        const files = fs.readdirSync(dirPath, { withFileTypes: true });
        const jars = [];

        for (const dirent of files) {
            if (dirent.isDirectory() || !/\.jar(\.disabled)?$/.test(dirent.name)) continue;
            const fullPath = path.join(dirPath, dirent.name);
            const stat = fs.statSync(fullPath);
            const baseName = dirent.name.replace(/\.disabled$/, '');
            let info = { name: baseName.replace(/\.jar$/, ''), version: 'Unknown', description: null, author: null, website: null };

            try {
                const zip = new AdmZip(fullPath);
                let metaEntry = zip.getEntry('plugin.yml') || zip.getEntry('paper-plugin.yml') || zip.getEntry('bungee.yml');
                if (metaEntry) {
                    const data = yaml.load(zip.readAsText(metaEntry));
                    info = {
                        name: data.name || info.name,
                        version: String(data.version || 'Unknown'),
                        description: data.description || null,
                        author: data.author || (data.authors && data.authors[0]) || null,
                        website: data.website || null
                    };
                } else {
                    const fabricEntry = zip.getEntry('fabric.mod.json');
                    const quiltEntry = zip.getEntry('quilt.mod.json');
                    const modEntry = fabricEntry || quiltEntry;
                    if (modEntry) {
                        const data = JSON.parse(zip.readAsText(modEntry));
                        info = {
                            name: data.name || data.id || info.name,
                            version: String(data.version || 'Unknown'),
                            description: data.description || null,
                            author: (data.authors && data.authors[0] && (data.authors[0].name || data.authors[0])) || null,
                            website: (data.contact && data.contact.homepage) || null
                        };
                    } else {
                        const manifest = zip.getEntry('META-INF/MANIFEST.MF');
                        if (manifest) {
                            const versionMatch = zip.readAsText(manifest).match(/Implementation-Version:\s*(.+)/i);
                            if (versionMatch) info.version = versionMatch[1].trim();
                        }
                    }
                }
            } catch (err) {
                // Corrupt/unreadable jar - fall back to filename-derived info above
            }

            jars.push({
                ...info,
                filename: dirent.name,
                size: stat.size,
                formattedSize: formatFileSize(stat.size),
                enabled: !dirent.name.endsWith('.disabled')
            });
        }

        jars.sort((a, b) => a.name.localeCompare(b.name));
        res.json({ success: true, jars });
    } catch (e) {
        console.error('Jar list error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Get the total size of a directory (or a single file) in bytes
app.get('/api/servers/:id/dirsize', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const targetPath = req.query.path || '/';
        const fullPath = resolveServerPath(serverId, targetPath);
        if (!fs.existsSync(fullPath)) return res.json({ success: true, size: 0 });

        let size = 0;
        const walk = (p) => {
            const stats = fs.statSync(p);
            if (stats.isDirectory()) {
                fs.readdirSync(p).forEach(f => walk(path.join(p, f)));
            } else {
                size += stats.size;
            }
        };
        walk(fullPath);
        res.json({ success: true, size });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// Create a full-server backup zip (excluding lock/pid files and the live log) and
// stream it back as the response body, rather than saving it permanently on the
// node - the panel is the system of record for backup files either way.
app.post('/api/servers/:id/backup', validateApiKey, (req, res) => {
    try {
        const serverId = req.params.id;
        const serverDir = resolveServerPath(serverId);
        if (!fs.existsSync(serverDir)) return res.status(404).json({ error: 'Server directory not found' });

        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="backup-${Date.now()}.zip"`);

        const archive = archiver('zip', { zlib: { level: 9 } });
        archive.on('error', (err) => {
            console.error('Backup archive error:', err);
            if (!res.headersSent) res.status(500).json({ success: false, error: err.message });
            else res.end();
        });
        archive.pipe(res);
        archive.glob('**/*', { cwd: serverDir, ignore: ['*.pid', '*.lock', 'logs/latest.log'] });
        archive.finalize();
    } catch (e) {
        console.error('Backup error:', e);
        if (!res.headersSent) res.status(500).json({ success: false, error: e.message });
    }
});

// Restore a full-server backup: accepts the zip as a multipart upload, wipes the
// existing server directory, and extracts the backup in its place.
const restoreUpload = multer({ dest: path.join(os.tmpdir(), 'agent-restores') });
app.post('/api/servers/:id/restore', validateApiKey, restoreUpload.single('backup'), async (req, res) => {
    const serverId = req.params.id;
    try {
        if (!req.file) return res.status(400).json({ error: 'No backup file uploaded' });
        const serverDir = resolveServerPath(serverId);

        if (fs.existsSync(serverDir)) {
            for (const entry of fs.readdirSync(serverDir)) {
                try {
                    fs.rmSync(path.join(serverDir, entry), { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
                } catch (err) {
                    console.warn(`Failed to remove ${entry} during restore:`, err.message);
                }
            }
        } else {
            fs.mkdirSync(serverDir, { recursive: true });
        }

        const directory = await unzipper.Open.file(req.file.path);
        if (!directory || !directory.files || directory.files.length === 0) {
            throw new Error('Backup file is empty or invalid');
        }
        await directory.extract({ path: serverDir });

        res.json({ success: true });
    } catch (e) {
        console.error('Restore error:', e);
        res.status(500).json({ success: false, error: e.message });
    } finally {
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    }
});

// ================== SERVER MANAGEMENT ==================

// Start server
app.post('/api/servers/:id/start', validateApiKey, async (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    const config = serverConfigs[serverId] || req.body.config || {
        server_type: 'paper', version: 'latest', port: 25565, ram: 2048
    };
    
    console.log(`Starting server ${serverId} (${config.server_type})...`);
    
    if (serverProcesses[serverId]) {
        return res.json({ success: false, error: 'Already running' });
    }
    
    try {
        const worldLock = path.join(serverDir, 'world', 'session.lock');
        if (fs.existsSync(worldLock)) {
            try { fs.unlinkSync(worldLock); } catch(e) {}
        }
        
        let javaPath = 'java';
        let javaArgs = [];
        
        if (config.server_type === 'bedrock') {
            let execPath = path.join(serverDir, process.platform === 'win32' ? 'bedrock_server.exe' : 'bedrock_server');
            if (!fs.existsSync(execPath)) {
                await downloadServerJar('bedrock', 'latest', serverDir);
            }
            javaPath = execPath;
        } else {
            const jarPath = path.join(serverDir, 'server.jar');
            if (!fs.existsSync(jarPath)) {
                await downloadServerJar(config.server_type, config.version, serverDir);
            }
            const xms = Math.max(256, Math.floor(config.ram / 4));
            javaArgs = ['-Xms' + xms + 'M', '-Xmx' + config.ram + 'M', '-jar', 'server.jar', 'nogui'];
        }
        
        const serverProc = spawn(javaPath, javaArgs, { cwd: serverDir, detached: false, stdio: 'pipe' });
        
        serverProcesses[serverId] = { pid: serverProc.pid, startedAt: Date.now(), config };
        liveProcessHandles[serverId] = serverProc;
        serverConsoles[serverId] = [];
        consoleWebSocketClients[serverId] = [];
        
        // Minecraft server output (Paper, spark, and various plugins) can include
        // ANSI escape sequences for colored terminal output. The panel's console
        // is plain text, not a terminal emulator, so without stripping these the
        // user sees the raw escape codes as garbled text (e.g. "[38;2;170;...m")
        // instead of either color or clean plain text.
        const stripAnsi = (str) => str.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '');

        const appendConsoleLine = (line) => {
            line = stripAnsi(line);
            serverConsoles[serverId].push(line);
            if (serverConsoles[serverId].length > 1000) serverConsoles[serverId].shift();
            consoleWebSocketClients[serverId].forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({ type: 'console', line }));
                }
            });
        };
        
        serverProc.stdout.on('data', data => {
            data.toString().split('\n').filter(Boolean).forEach(line => appendConsoleLine(line));
        });
        
        serverProc.stderr.on('data', data => {
            data.toString().split('\n').filter(Boolean).forEach(line => appendConsoleLine('[ERR] ' + line));
        });
        
        serverProc.on('exit', code => {
            appendConsoleLine(`[SYSTEM] Server exited with code ${code}`);
            console.log(`Server ${serverId} exited with code ${code}`);
            delete serverProcesses[serverId];
            delete liveProcessHandles[serverId];
            saveProcesses();
            consoleWebSocketClients[serverId].forEach(client => client.close());
        });
        
        saveProcesses();
        res.json({ success: true });
        
    } catch (e) {
        console.error('Start server error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Stop server
app.post('/api/servers/:id/stop', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    if (serverProcesses[serverId]) {
        try {
            const pid = serverProcesses[serverId].pid;
            if (process.platform === 'win32') {
                exec(`taskkill /F /PID ${pid}`, err => { if(err) console.error(err.message); });
            } else {
                process.kill(pid, 'SIGTERM');
            }
        } catch (e) {
            console.error('Stop server error:', e);
        }
        delete serverProcesses[serverId];
        saveProcesses();
    }
    res.json({ success: true });
});

// Kill server
app.post('/api/servers/:id/kill', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    if (serverProcesses[serverId]) {
        try {
            const pid = serverProcesses[serverId].pid;
            if (process.platform === 'win32') {
                execSync(`taskkill /F /PID ${pid}`);
            } else {
                process.kill(pid, 'SIGKILL');
            }
        } catch (e) {
            console.error('Kill server error:', e);
        }
        delete serverProcesses[serverId];
        saveProcesses();
    }
    res.json({ success: true });
});

// Get server status
app.get('/api/servers/:id/status', validateApiKey, async (req, res) => {
    const serverId = req.params.id;
    let status = 'stopped';
    let cpu = 0, memory = 0;
    
    if (serverProcesses[serverId]) {
        try {
            const stats = await pidusage(serverProcesses[serverId].pid);
            status = 'running';
            cpu = stats.cpu;
            memory = stats.memory;
        } catch (e) {
            delete serverProcesses[serverId];
            saveProcesses();
        }
    }
    res.json({ status, cpu, memory });
});

// Get console log
app.get('/api/servers/:id/console', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const lines = serverConsoles[serverId] || [];
    res.json({ success: true, lines });
});

// Send server command
app.post('/api/servers/:id/command', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const { command } = req.body;
    
    if (!serverProcesses[serverId]) {
        return res.json({ success: false, error: 'Server not running' });
    }
    if (!command) {
        return res.json({ success: false, error: 'Command required' });
    }
    
    try {
        const proc = liveProcessHandles[serverId];
        if (!proc || !proc.stdin || !proc.stdin.writable) {
            return res.json({ success: false, error: 'Server process is not accepting input' });
        }
        proc.stdin.write(command.endsWith('\n') ? command : command + '\n');
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// Delete server
// Reinstall a server: clean core files (and optionally plugins/worlds/logs/configs),
// then redownload the jar for a new server_type/version. Mirrors the panel's local
// reinstall logic, done on the node itself rather than round-tripping every file
// operation through the panel.
app.post('/api/servers/:id/reinstall', validateApiKey, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { server_type, version, cleanOptions = {} } = req.body;
        if (!server_type || !version) return res.status(400).json({ error: 'server_type and version are required' });

        const serverDir = resolveServerPath(serverId);
        fs.mkdirSync(serverDir, { recursive: true });

        // Stop the server if it's currently tracked as running
        if (serverProcesses[serverId]) {
            try {
                const pid = serverProcesses[serverId].pid;
                process.platform === 'win32' ? exec(`taskkill /F /PID ${pid}`) : process.kill(pid, 'SIGKILL');
            } catch (e) { /* already dead */ }
            delete serverProcesses[serverId];
            saveProcesses();
        }

        // Back up config files we want to carry over
        const backupFiles = ['server.properties', 'ops.json', 'whitelist.json', 'banned-players.json', 'banned-ips.json'];
        const backupData = {};
        backupFiles.forEach(file => {
            const fp = path.join(serverDir, file);
            if (fs.existsSync(fp)) backupData[file] = fs.readFileSync(fp, 'utf8');
        });

        // Always clean core files so the new jar/libs aren't mixed with the old ones
        ['server.jar', 'libraries', 'versions', 'cache'].forEach(file => {
            const fp = path.join(serverDir, file);
            if (fs.existsSync(fp)) fs.rmSync(fp, { recursive: true, force: true });
        });

        const cleaningActions = [];
        if (cleanOptions.cleanPlugins) {
            const pluginsDir = path.join(serverDir, 'plugins');
            if (fs.existsSync(pluginsDir)) { fs.rmSync(pluginsDir, { recursive: true, force: true }); fs.mkdirSync(pluginsDir, { recursive: true }); cleaningActions.push('Plugins'); }
        }
        if (cleanOptions.cleanWorlds) {
            ['world', 'world_nether', 'world_the_end'].forEach(w => {
                const wp = path.join(serverDir, w);
                if (fs.existsSync(wp)) { fs.rmSync(wp, { recursive: true, force: true }); cleaningActions.push(w); }
            });
        }
        if (cleanOptions.cleanLogs) {
            const logsDir = path.join(serverDir, 'logs');
            if (fs.existsSync(logsDir)) { fs.rmSync(logsDir, { recursive: true, force: true }); fs.mkdirSync(logsDir, { recursive: true }); cleaningActions.push('Logs'); }
        }
        if (cleanOptions.cleanConfigs) {
            ['config', 'configurations'].forEach(c => {
                const cp = path.join(serverDir, c);
                if (fs.existsSync(cp)) { fs.rmSync(cp, { recursive: true, force: true }); cleaningActions.push('Configs'); }
            });
            ['bukkit.yml', 'spigot.yml', 'paper.yml', 'purpur.yml', 'commands.yml', 'help.yml'].forEach(file => {
                const fp = path.join(serverDir, file);
                if (fs.existsSync(fp)) fs.unlinkSync(fp);
            });
        }

        // Download the new jar (or, for Bedrock, the extracted server files)
        const actualVersion = await downloadServerJar(server_type, version, serverDir);

        // Restore the configs we backed up, then make sure eula.txt exists
        Object.entries(backupData).forEach(([file, content]) => {
            fs.writeFileSync(path.join(serverDir, file), content, 'utf8');
        });
        const eulaPath = path.join(serverDir, 'eula.txt');
        if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n', 'utf8');

        res.json({ success: true, actualVersion, cleaningActions });
    } catch (e) {
        console.error('Reinstall error:', e);
        res.status(500).json({ success: false, error: e.message });
    }
});

app.delete('/api/servers/:id', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    
    if (serverProcesses[serverId]) {
        try {
            const pid = serverProcesses[serverId].pid;
            if (process.platform === 'win32') {
                exec(`taskkill /F /PID ${pid}`, (err) => { if(err) console.error(err); });
            } else {
                process.kill(pid, 'SIGKILL');
            }
        } catch (e) {
            console.error('Process kill error:', e);
        }
        delete serverProcesses[serverId];
        saveProcesses();
    }
    
    if (fs.existsSync(serverDir)) {
        fs.rmSync(serverDir, { recursive: true, force: true });
    }
    delete serverConfigs[serverId];
    
    res.json({ success: true });
});

// WebSocket for console streaming
wss.on('connection', (ws, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const serverId = url.searchParams.get('server');
    const apiKey = url.searchParams.get('api_key');
    
    if (API_KEY && apiKey !== API_KEY) {
        ws.close(1008, 'Unauthorized');
        return;
    }
    if (!serverId) {
        ws.close(1008, 'Server ID required');
        return;
    }
    
    console.log(`Console client connected for server ${serverId}`);
    
    if (!consoleWebSocketClients[serverId]) {
        consoleWebSocketClients[serverId] = [];
    }
    consoleWebSocketClients[serverId].push(ws);
    
    // Send existing logs
    (serverConsoles[serverId] || []).forEach(line => {
        ws.send(JSON.stringify({ type: 'console', line }));
    });
    
    ws.on('close', () => {
        console.log(`Console client disconnected for server ${serverId}`);
        if (consoleWebSocketClients[serverId]) {
            const index = consoleWebSocketClients[serverId].indexOf(ws);
            if (index !== -1) {
                consoleWebSocketClients[serverId].splice(index, 1);
            }
        }
    });
});

loadSavedProcesses();

// Start server
server.listen(PORT, '0.0.0.0', () => {
    console.log('='.repeat(60));
    console.log('  NODE AGENT STARTED (COMPLETE VERSION)');
    console.log('='.repeat(60));
    console.log(`  Port: ${PORT}`);
    console.log(`  Data directory: ${DATA_DIR}`);
    console.log(`  Hostname: ${os.hostname()}`);
    if (API_KEY) {
        console.log('  API Key configured');
    } else {
        console.warn('  WARNING: No API key!');
    }
    console.log('='.repeat(60));
    console.log('');
});

module.exports = { app, wss };
