const db = require('better-sqlite3')('database.db');
const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(3);
console.log('Server 3:', server);