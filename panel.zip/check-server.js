const db = require('better-sqlite3')('database.db');
console.log('=== Server 3 ===');
console.log(db.prepare('SELECT * FROM servers WHERE id = ?').get(3));
console.log('=== Nodes ===');
console.log(db.prepare('SELECT * FROM nodes').all());