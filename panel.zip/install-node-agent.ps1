# Minecraft Panel Node Agent Setup Script for Windows
# Run PowerShell as Administrator!

param(
    [switch]$SkipNodeCheck
)

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Minecraft Panel Node Agent Setup" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check admin privileges
$IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $IsAdmin) {
    Write-Host "❌ Please run PowerShell as Administrator!" -ForegroundColor Red
    pause
    exit 1
}

# Step 1: Check if Node.js is installed
if (-not $SkipNodeCheck) {
    Write-Host "Checking Node.js installation..."
    try {
        $nodeVersion = node -v
        Write-Host "✓ Node.js $nodeVersion found!" -ForegroundColor Green
    } catch {
        Write-Host "⚠️ Node.js not found!" -ForegroundColor Yellow
        Write-Host "Please install Node.js from https://nodejs.org/"
        Write-Host "Download LTS version (recommended)"
        pause
        exit 1
    }
}

# Step 2: Create installation directory
$installDir = "C:\Program Files\Minecraft Panel Node Agent"
Write-Host "`nCreating installation directory at $installDir..."
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}
Set-Location $installDir

# Step 3: Copy node agent files
Write-Host "`nCopying node agent files..."

# Write node-agent.js
$nodeAgentContent = @"
const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const pidusage = require('pidusage');

// Load environment variables
let envConfig = {};
try {
    const envPath = path.join(__dirname, '.agent-env');
    if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        envContent.split('\n').forEach(line => {
            const [key, value] = line.split('=');
            if (key && value) {
                envConfig[key.trim()] = value.trim();
            }
        });
    }
} catch (e) {
    console.log('No .agent-env file found, using defaults');
}

const app = express();
const PORT = process.env.AGENT_PORT || envConfig.AGENT_PORT || 3001;
const API_KEY = process.env.AGENT_API_KEY || envConfig.AGENT_API_KEY || null;
const DATA_DIR = path.join(__dirname, 'node-data');
const SERVERS_DIR = path.join(DATA_DIR, 'servers');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

app.use(express.json());

const validateApiKey = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    if (!API_KEY) {
        console.warn('Warning: No API key configured! This is insecure.');
        return next();
    }
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
};

const serverProcesses = {};
const resolveServerPath = (serverId) => path.join(SERVERS_DIR, serverId.toString());

app.get('/api/stats', validateApiKey, (req, res) => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    let diskTotal = 1000000;
    let diskUsed = 500000;
    
    res.json({
        memory_total: Math.round(totalMem / (1024 * 1024)),
        memory_used: Math.round(usedMem / (1024 * 1024)),
        disk_total: diskTotal,
        disk_used: diskUsed,
        cpu_cores: os.cpus().length,
        uptime: os.uptime()
    });
});

app.get('/api/servers', validateApiKey, (req, res) => {
    const servers = [];
    if (fs.existsSync(SERVERS_DIR)) {
        const dirs = fs.readdirSync(SERVERS_DIR);
        dirs.forEach(dir => {
            servers.push({ id: dir, status: 'stopped' });
        });
    }
    res.json(servers);
});

app.post('/api/servers/:id/create', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    if (!fs.existsSync(serverDir)) {
        fs.mkdirSync(serverDir, { recursive: true });
    }
    res.json({ success: true });
});

app.post('/api/servers/:id/start', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    const serverDir = resolveServerPath(serverId);
    
    if (serverProcesses[serverId]) {
        return res.json({ success: false, error: 'Server already running' });
    }
    
    const cmd = process.platform === 'win32' ? 'ping' : 'ping';
    const args = process.platform === 'win32' ? ['localhost', '-t'] : ['localhost', '-c', '10000'];
    
    const process = spawn(cmd, args, { cwd: serverDir });
    serverProcesses[serverId] = process;
    res.json({ success: true });
});

app.post('/api/servers/:id/stop', validateApiKey, (req, res) => {
    const serverId = req.params.id;
    if (serverProcesses[serverId]) {
        serverProcesses[serverId].kill('SIGTERM');
        delete serverProcesses[serverId];
    }
    res.json({ success: true });
});

app.get('/api/servers/:id/status', validateApiKey, async (req, res) => {
    const serverId = req.params.id;
    const isRunning = !!serverProcesses[serverId];
    let stats = { status: 'stopped' };
    
    if (isRunning && serverProcesses[serverId].pid) {
        try {
            const usage = await pidusage(serverProcesses[serverId].pid);
            stats = {
                status: 'running',
                cpu: usage.cpu,
                memory: usage.memory / (1024 * 1024)
            };
        } catch (e) {
            stats.status = 'stopped';
            delete serverProcesses[serverId];
        }
    }
    
    res.json(stats);
});

app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log('='.repeat(60));
    console.log('  Node Agent Started');
    console.log('='.repeat(60));
    console.log(`  Port: ${PORT}`);
    console.log(`  Data Directory: ${DATA_DIR}`);
    if (API_KEY) {
        console.log('  API Key Configured');
    } else {
        console.warn('  WARNING: No API Key configured! Insecure.');
    }
    console.log('='.repeat(60));
    console.log('');
});
"@

$nodeAgentContent | Out-File -FilePath "node-agent.js" -Encoding UTF8

# Write package.json
$packageJsonContent = @"
{
  "name": "minecraft-panel-node-agent",
  "version": "1.0.0",
  "description": "Node agent for Minecraft panel multi-node system",
  "main": "node-agent.js",
  "dependencies": {
    "express": "^4.18.2",
    "pidusage": "^4.0.1"
  }
}
"@

$packageJsonContent | Out-File -FilePath "package.json" -Encoding UTF8

# Step 4: Install dependencies
Write-Host "`nInstalling dependencies..."
npm install

# Step 5: Create example config
$configPath = Join-Path $installDir ".agent-env"
if (-not (Test-Path $configPath)) {
    $configContent = @"
AGENT_PORT=3001
AGENT_API_KEY=your-api-key-here
"@
    $configContent | Out-File -FilePath $configPath -Encoding UTF8
    Write-Host "`n⚠️  IMPORTANT: Edit $configPath and set your API key!" -ForegroundColor Yellow
}

# Step 6: Create startup script
$startupScript = @"
@echo off
cd /d "%~dp0"
echo Starting Minecraft Panel Node Agent...
node node-agent.js
pause
"@
$startupScript | Out-File -FilePath "start-node-agent.bat" -Encoding ASCII

# Step 7: Firewall rule
Write-Host "`nSetting up Windows Firewall rule..."
try {
    New-NetFirewallRule -DisplayName "Minecraft Panel Node Agent" -Direction Inbound -LocalPort 3001 -Protocol TCP -Action Allow -ErrorAction Stop | Out-Null
    Write-Host "✓ Firewall rule created!" -ForegroundColor Green
} catch {
    Write-Host "⚠️ Firewall rule might already exist or failed to create" -ForegroundColor Yellow
}

Write-Host "`n==========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete!" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Edit $configPath to set your API key"
Write-Host "2. Run 'start-node-agent.bat' to start the agent"
Write-Host "3. (Optional) Create a scheduled task to run on boot"
Write-Host ""
Write-Host "Then add the node in your panel's admin area!"
Write-Host ""
pause
