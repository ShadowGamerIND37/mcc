const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

module.exports = (db, dbGet, dbAll, dbRun, globalSettings, serverProcesses, onlinePlayers, liveStats, helpers = {}) => {
  const {
    startServer, stopServer, sendCommand, isServerRunning,
    logServerActivity, callNodeApi, updateNodeStats, isAuthorized
  } = helpers;

  const SERVERS_DIR = path.join(__dirname, '..', 'servers');

  // ================================================
  // API KEY AUTHENTICATION MIDDLEWARE
  // ================================================
  const authenticateAPIKey = async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized: No API key provided' });
      }

      const apiKey = authHeader.substring(7);
      const keyRecord = await dbGet('SELECT * FROM api_keys WHERE key = ? AND is_active = 1', [apiKey]);

      if (!keyRecord) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API key' });
      }

      const user = await dbGet('SELECT * FROM users WHERE id = ?', [keyRecord.user_id]);
      if (!user) {
        return res.status(401).json({ error: 'Unauthorized: User not found' });
      }

      req.apiKey = keyRecord;
      req.user = user;
      req.permissions = JSON.parse(keyRecord.permissions || '["read"]');

      // X-Panel-User-Id override: allow admin API keys to act as another user
      const overrideUserId = req.headers['x-panel-user-id'];
      if (overrideUserId && (req.permissions.includes('admin') || req.permissions.includes('*'))) {
        const overrideUser = await dbGet('SELECT * FROM users WHERE id = ?', [parseInt(overrideUserId)]);
        if (overrideUser) {
          req.user = overrideUser;
        }
      }

      next();
    } catch (error) {
      console.error('API auth error:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  };

  const hasPermission = (required) => {
    return (req, res, next) => {
      if (!req.permissions.includes(required) && !req.permissions.includes('*')) {
        return res.status(403).json({ error: 'Forbidden: Insufficient permissions' });
      }
      next();
    };
  };

  const requireAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden: Admin privileges required' });
    }
    next();
  };

  // ================================================
  // PUBLIC ENDPOINTS
  // ================================================
  router.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // ================================================
  // API KEY MANAGEMENT (requires admin)
  // ================================================
  router.post('/keys', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const { name, user_id, permissions = ['read'] } = req.body;
      if (!name) {
        return res.status(400).json({ error: 'Name is required' });
      }
      const targetUserId = user_id || req.user.id;
      const newKey = 'mcpanel_' + uuidv4().replace(/-/g, '');
      await dbRun(
        'INSERT INTO api_keys (user_id, name, key, permissions) VALUES (?, ?, ?, ?)',
        [targetUserId, name, newKey, JSON.stringify(permissions)]
      );
      res.status(201).json({ key: newKey, name, permissions, user_id: targetUserId });
    } catch (error) {
      console.error('Create API key error:', error);
      res.status(500).json({ error: 'Failed to create API key' });
    }
  });

  router.get('/keys', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const keys = await dbAll('SELECT id, user_id, name, permissions, is_active, created_at FROM api_keys');
      res.json({ keys });
    } catch (error) {
      console.error('Get API keys error:', error);
      res.status(500).json({ error: 'Failed to get API keys' });
    }
  });

  router.delete('/keys/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      await dbRun('DELETE FROM api_keys WHERE id = ?', [req.params.id]);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete API key error:', error);
      res.status(500).json({ error: 'Failed to delete API key' });
    }
  });

  // ================================================
  // SERVER ENDPOINTS
  // ================================================
  router.get('/servers', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      let servers;
      if (req.user.role === 'admin') {
        servers = await dbAll('SELECT * FROM servers');
      } else {
        servers = await dbAll('SELECT * FROM servers WHERE owner_id = ?', [req.user.id]);
      }

      const serversWithStats = servers.map(server => ({
        ...server,
        stats: liveStats[server.id] || null,
        players: onlinePlayers[server.id] || []
      }));

      res.json({ servers: serversWithStats });
    } catch (error) {
      console.error('Get servers error:', error);
      res.status(500).json({ error: 'Failed to get servers' });
    }
  });

  router.get('/servers/:id', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const serverId = req.params.id;
      let server;

      if (req.user.role === 'admin') {
        server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      } else {
        server = await dbGet('SELECT * FROM servers WHERE id = ? AND owner_id = ?', [serverId, req.user.id]);
      }

      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }

      res.json({
        server,
        stats: liveStats[serverId] || null,
        players: onlinePlayers[serverId] || []
      });
    } catch (error) {
      console.error('Get server error:', error);
      res.status(500).json({ error: 'Failed to get server' });
    }
  });

  // ================================================
  // SERVER CONTROL ENDPOINTS (requires write)
  // ================================================
  router.post('/servers/:id/start', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      if (await isServerRunning(serverId)) return res.status(400).json({ error: 'Server already running' });
      await startServer(serverId);
      if (logServerActivity) await logServerActivity(serverId, 'start', null, req.user.id, req.ip);
      res.json({ success: true, message: 'Server started' });
    } catch (err) {
      console.error('API start server error:', err);
      res.status(500).json({ error: err.message || 'Failed to start server' });
    }
  });

  router.post('/servers/:id/stop', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      await stopServer(serverId, false);
      if (logServerActivity) await logServerActivity(serverId, 'stop', null, req.user.id, req.ip);
      res.json({ success: true, message: 'Server stopped' });
    } catch (err) {
      console.error('API stop server error:', err);
      res.status(500).json({ error: err.message || 'Failed to stop server' });
    }
  });

  router.post('/servers/:id/restart', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      if (!await isServerRunning(serverId)) return res.status(400).json({ error: 'Server not running' });
      const stopped = await stopServer(serverId);
      if (!stopped) return res.status(500).json({ error: 'Failed to stop server' });
      await new Promise(resolve => setTimeout(resolve, 2000));
      const started = await startServer(serverId);
      if (started === false) return res.status(500).json({ error: 'Failed to start server after stopping' });
      if (logServerActivity) await logServerActivity(serverId, 'restart', null, req.user.id, req.ip);
      res.json({ success: true, message: 'Server restarted' });
    } catch (err) {
      console.error('API restart server error:', err);
      res.status(500).json({ error: err.message || 'Failed to restart server' });
    }
  });

  router.post('/servers/:id/kill', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      const success = await stopServer(serverId, true);
      if (success) {
        if (logServerActivity) await logServerActivity(serverId, 'kill', null, req.user.id, req.ip);
        res.json({ success: true, message: 'Server killed' });
      } else {
        res.status(500).json({ error: 'Failed to kill server' });
      }
    } catch (err) {
      console.error('API kill server error:', err);
      res.status(500).json({ error: err.message || 'Failed to kill server' });
    }
  });

  router.post('/servers/:id/command', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const { command } = req.body;
      if (!command) return res.status(400).json({ error: 'Command is required' });
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      if (!await isServerRunning(serverId)) return res.status(400).json({ error: 'Server not running' });
      if (server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node) {
          await callNodeApi(node, `/api/servers/${serverId}/command`, 'POST', { command }, true);
        }
      } else {
        await sendCommand(serverId, command);
      }
      if (logServerActivity) await logServerActivity(serverId, 'command', command, req.user.id, req.ip);
      res.json({ success: true, message: 'Command sent' });
    } catch (err) {
      console.error('API command error:', err);
      res.status(500).json({ error: err.message || 'Failed to send command' });
    }
  });

  router.get('/servers/:id/console', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });

      let logContent = '';
      if (server.node_id) {
        try {
          const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
          if (node) {
            const consoleResult = await callNodeApi(node, `/api/servers/${serverId}/console`);
            logContent = (consoleResult.lines || []).join('\n');
          }
        } catch (err) {
          console.log('Failed to fetch node console:', err);
        }
      } else {
        const logPath = path.join(SERVERS_DIR, serverId.toString(), 'logs', 'latest.log');
        if (fs.existsSync(logPath)) {
          try {
            const stats = fs.statSync(logPath);
            const maxRead = 100 * 1024;
            const readLength = Math.min(stats.size, maxRead);
            const buffer = Buffer.alloc(readLength);
            const fd = fs.openSync(logPath, 'r');
            fs.readSync(fd, buffer, 0, readLength, stats.size - readLength);
            fs.closeSync(fd);
            logContent = buffer.toString('utf8').replace(/\x1b\[[0-9;]*m/g, '');
          } catch {}
        }
      }

      res.json({ serverId, logContent, stats: liveStats[serverId] || {} });
    } catch (err) {
      console.error('API console error:', err);
      res.status(500).json({ error: 'Failed to get console logs' });
    }
  });

  // ================================================
  // PLAYER ENDPOINTS
  // ================================================
  router.get('/servers/:id/players', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });

      const players = onlinePlayers[serverId] || [];

      let whitelist = [];
      let ops = [];
      let bans = [];

      if (server.node_id) {
        try {
          const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
          if (node) {
            const wl = await callNodeApi(node, `/api/servers/${serverId}/files/view?path=/whitelist.json`, 'GET', null, true);
            whitelist = JSON.parse(wl.content || '[]');
            const op = await callNodeApi(node, `/api/servers/${serverId}/files/view?path=/ops.json`, 'GET', null, true);
            ops = JSON.parse(op.content || '[]');
          }
        } catch {}
      } else {
        const sDir = path.join(SERVERS_DIR, serverId.toString());
        const wlPath = path.join(sDir, 'whitelist.json');
        const opPath = path.join(sDir, 'ops.json');
        const banPath = path.join(sDir, 'banned-players.json');
        try { whitelist = JSON.parse(fs.readFileSync(wlPath, 'utf8')); } catch {}
        try { ops = JSON.parse(fs.readFileSync(opPath, 'utf8')); } catch {}
        try { bans = JSON.parse(fs.readFileSync(banPath, 'utf8')); } catch {}
      }

      res.json({ serverId, online: players, whitelist, ops, bans });
    } catch (err) {
      console.error('API players error:', err);
      res.status(500).json({ error: 'Failed to get players' });
    }
  });

  // ================================================
  // NODE ENDPOINTS (admin)
  // ================================================
  router.get('/nodes', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const nodes = await dbAll('SELECT * FROM nodes ORDER BY id');
      res.json({ nodes });
    } catch (error) {
      console.error('Get nodes error:', error);
      res.status(500).json({ error: 'Failed to get nodes' });
    }
  });

  router.get('/nodes/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
      if (!node) return res.status(404).json({ error: 'Node not found' });
      const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE node_id = ?', [node.id]);
      res.json({ node, serverCount: serverCount ? serverCount.count : 0 });
    } catch (error) {
      console.error('Get node error:', error);
      res.status(500).json({ error: 'Failed to get node' });
    }
  });

  router.post('/nodes/:id/refresh', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [req.params.id]);
      if (!node) return res.status(404).json({ error: 'Node not found' });
      if (updateNodeStats) {
        await updateNodeStats(node);
      }
      const updated = await dbGet('SELECT * FROM nodes WHERE id = ?', [node.id]);
      res.json({ success: true, node: updated });
    } catch (err) {
      console.error('Refresh node error:', err);
      res.status(500).json({ error: err.message || 'Failed to refresh node' });
    }
  });

  router.post('/nodes/:id/delete', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const nodeId = req.params.id;
      const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE node_id = ?', [nodeId]);
      if (serverCount && serverCount.count > 0) {
        return res.status(400).json({ error: `Cannot delete node with ${serverCount.count} server(s) assigned` });
      }
      await dbRun('DELETE FROM allocations WHERE node_id = ?', [nodeId]);
      await dbRun('DELETE FROM nodes WHERE id = ?', [nodeId]);
      res.json({ success: true });
    } catch (err) {
      console.error('Delete node error:', err);
      res.status(500).json({ error: 'Failed to delete node' });
    }
  });

  router.post('/nodes', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const { name, ip_address, port, api_key } = req.body;
      if (!name || !ip_address || !port || !api_key) {
        return res.status(400).json({ error: 'name, ip_address, port, and api_key are required' });
      }
      const tempNode = { ip_address, port: parseInt(port), api_key };
      let memory_total = 0, disk_total = 0, cpu_cores = 0, status = 'offline';
      try {
        if (callNodeApi) {
          const stats = await callNodeApi(tempNode, '/api/stats');
          status = 'online';
          memory_total = stats.memory_total;
          disk_total = stats.disk_total;
          cpu_cores = stats.cpu_cores;
        }
      } catch {}
      await dbRun(
        'INSERT INTO nodes (name, ip_address, port, api_key, status, memory_total, disk_total, cpu_cores) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [name, ip_address, parseInt(port), api_key, status, memory_total, disk_total, cpu_cores]
      );
      res.status(201).json({ success: true, message: 'Node created' });
    } catch (err) {
      console.error('Create node error:', err);
      res.status(500).json({ error: 'Failed to create node' });
    }
  });

  // ================================================
  // USER MANAGEMENT ENDPOINTS (admin)
  // ================================================
  router.get('/users', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const users = await dbAll('SELECT id, username, email, role, status, created_at FROM users');
      res.json({ users });
    } catch (error) {
      console.error('Get users error:', error);
      res.status(500).json({ error: 'Failed to get users' });
    }
  });

  router.get('/users/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const user = await dbGet('SELECT id, username, email, role, status, created_at FROM users WHERE id = ?', [req.params.id]);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE owner_id = ?', [user.id]);
      res.json({ user, serverCount: serverCount ? serverCount.count : 0 });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ error: 'Failed to get user' });
    }
  });

  router.post('/users', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const { username, email, password, role = 'user', status = 'active' } = req.body;
      if (!username || !email || !password) {
        return res.status(400).json({ error: 'username, email, and password are required' });
      }
      if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
        return res.status(400).json({ error: 'Invalid username format' });
      }
      if (password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters' });
      }
      const existing = await dbGet('SELECT * FROM users WHERE username = ? OR email = ?', [username, email]);
      if (existing) return res.status(400).json({ error: 'Username or email already exists' });
      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash(password, 10);
      const result = await dbRun(
        'INSERT INTO users (username, email, password, role, status) VALUES (?, ?, ?, ?, ?)',
        [username, email, hashedPassword, role, status]
      );
      res.status(201).json({ success: true, userId: result.lastID, username, email, role, status });
    } catch (err) {
      console.error('Create user error:', err);
      res.status(500).json({ error: 'Failed to create user' });
    }
  });

  router.put('/users/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const { username, email, role, status, password } = req.body;
      if (!username || !email || !role || !status) {
        return res.status(400).json({ error: 'username, email, role, and status are required' });
      }
      if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
        return res.status(400).json({ error: 'Invalid username format' });
      }
      const existing = await dbGet('SELECT * FROM users WHERE (username = ? OR email = ?) AND id != ?', [username, email, userId]);
      if (existing) return res.status(400).json({ error: 'Username or email already in use' });
      const bcrypt = require('bcryptjs');
      if (password && password.length > 0) {
        if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
        const hashedPassword = await bcrypt.hash(password, 10);
        await dbRun('UPDATE users SET username = ?, email = ?, role = ?, status = ?, password = ? WHERE id = ?',
          [username, email, role, status, hashedPassword, userId]);
      } else {
        await dbRun('UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?',
          [username, email, role, status, userId]);
      }
      res.json({ success: true, message: 'User updated' });
    } catch (err) {
      console.error('Update user error:', err);
      res.status(500).json({ error: 'Failed to update user' });
    }
  });

  router.delete('/users/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const userId = req.params.id;
      const userServers = await dbAll('SELECT * FROM servers WHERE owner_id = ?', [userId]);
      if (userServers.length > 0) {
        return res.status(400).json({ error: `Cannot delete user with ${userServers.length} active server(s)` });
      }
      await dbRun('DELETE FROM users WHERE id = ?', [userId]);
      res.json({ success: true, message: 'User deleted' });
    } catch (err) {
      console.error('Delete user error:', err);
      res.status(500).json({ error: 'Failed to delete user' });
    }
  });

  // ================================================
  // ADMIN SERVER MANAGEMENT ENDPOINTS
  // ================================================
  router.get('/admin/servers', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const search = req.query.search || '';
      const type = req.query.type || '';
      const status = req.query.status || '';
      let query = `SELECT s.*, u.username AS owner_name FROM servers s LEFT JOIN users u ON s.owner_id = u.id`;
      const params = [];
      const conditions = [];
      if (search) {
        conditions.push('(s.name LIKE ? OR u.username LIKE ?)');
        params.push(`%${search}%`, `%${search}%`);
      }
      if (type) { conditions.push('s.server_type = ?'); params.push(type); }
      if (status) { conditions.push('s.status = ?'); params.push(status); }
      if (conditions.length > 0) query += ' WHERE ' + conditions.join(' AND ');
      query += ' ORDER BY s.created_at DESC';
      const servers = await dbAll(query, params);
      const enriched = servers.map(s => ({ ...s, stats: liveStats[s.id] || null, players: onlinePlayers[s.id] || [] }));
      res.json({ servers: enriched });
    } catch (err) {
      console.error('Admin get servers error:', err);
      res.status(500).json({ error: 'Failed to get servers' });
    }
  });

  router.delete('/admin/servers/:id', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      if (server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node && callNodeApi) {
          try { await callNodeApi(node, `/api/servers/${serverId}`, 'DELETE', null, true); } catch {}
        }
      } else {
        const sDir = path.join(SERVERS_DIR, serverId.toString());
        if (fs.existsSync(sDir)) {
          fs.rmSync(sDir, { recursive: true, force: true });
        }
      }
      if (server.allocation_id) {
        await dbRun('UPDATE allocations SET server_id = NULL WHERE id = ?', [server.allocation_id]);
      }
      await dbRun('DELETE FROM server_activity WHERE server_id = ?', [serverId]);
      await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
      res.json({ success: true, message: 'Server deleted' });
    } catch (err) {
      console.error('Admin delete server error:', err);
      res.status(500).json({ error: 'Failed to delete server' });
    }
  });

  // ================================================
  // BILLING ENDPOINTS (read)
  // ================================================
  router.get('/billing/plans', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const plans = await dbAll(`
        SELECT p.id, p.name as product_name, pl.* FROM plans pl
        JOIN products p ON pl.product_id = p.id
        WHERE p.is_active = 1 ORDER BY pl.price ASC
      `);
      res.json({ plans });
    } catch (err) {
      console.error('Get plans error:', err);
      res.status(500).json({ error: 'Failed to get plans' });
    }
  });

  router.get('/billing/invoices', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      let invoices;
      if (req.user.role === 'admin' && req.query.all === 'true') {
        invoices = await dbAll(`
          SELECT i.*, u.username FROM invoices i
          LEFT JOIN users u ON i.user_id = u.id
          ORDER BY i.created_at DESC LIMIT 50
        `);
      } else {
        invoices = await dbAll('SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC LIMIT 20', [req.user.id]);
      }
      res.json({ invoices });
    } catch (err) {
      console.error('Get invoices error:', err);
      res.status(500).json({ error: 'Failed to get invoices' });
    }
  });

  // ================================================
  // PANEL STATS ENDPOINT (admin)
  // ================================================
  router.get('/stats', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const totalServers = await dbGet('SELECT COUNT(*) as count FROM servers');
      const totalUsers = await dbGet('SELECT COUNT(*) as count FROM users');
      const totalNodes = await dbGet('SELECT COUNT(*) as count FROM nodes');
      const runningServers = await dbGet("SELECT COUNT(*) as count FROM servers WHERE status = 'running'");
      const onlineNodes = await dbGet("SELECT COUNT(*) as count FROM nodes WHERE status = 'online'");
      const totalInvoices = await dbGet('SELECT COUNT(*) as count FROM invoices');
      const totalRevenue = await dbGet("SELECT SUM(amount) as total FROM invoices WHERE status = 'paid'");
      res.json({
        stats: {
          totalServers: totalServers ? totalServers.count : 0,
          totalUsers: totalUsers ? totalUsers.count : 0,
          totalNodes: totalNodes ? totalNodes.count : 0,
          runningServers: runningServers ? runningServers.count : 0,
          onlineNodes: onlineNodes ? onlineNodes.count : 0,
          totalInvoices: totalInvoices ? totalInvoices.count : 0,
          totalRevenue: totalRevenue ? totalRevenue.total : 0
        }
      });
    } catch (err) {
      console.error('Get stats error:', err);
      res.status(500).json({ error: 'Failed to get stats' });
    }
  });

  // ================================================
  // BACKUP ENDPOINTS
  // ================================================
  router.get('/servers/:id/backups', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      const backups = await dbAll('SELECT * FROM backups WHERE server_id = ? ORDER BY created_at DESC', [serverId]);
      res.json({ serverId, backups });
    } catch (err) {
      console.error('Get backups error:', err);
      res.status(500).json({ error: 'Failed to get backups' });
    }
  });

  router.post('/servers/:id/backups', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      const { name, description } = req.body;
      const backupName = name || `backup-${Date.now()}`;
      const backupDir = path.join(__dirname, '..', 'backups');
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
      const backupPath = path.join(backupDir, `${serverId}-${Date.now()}.zip`);

      if (server.node_id) {
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (node && callNodeApi) {
          await callNodeApi(node, `/api/servers/${serverId}/backup`, 'POST', { name: backupName }, true);
        }
        await dbRun(
          'INSERT INTO backups (server_id, file, name, description) VALUES (?, ?, ?, ?)',
          [serverId, backupPath, backupName, description || '']
        );
        return res.json({ success: true, message: 'Backup created on node' });
      }

      const archiver = require('archiver');
      const output = fs.createWriteStream(backupPath);
      const archive = archiver('zip', { zlib: { level: 6 } });
      archive.pipe(output);
      const sDir = path.join(SERVERS_DIR, serverId.toString());
      if (fs.existsSync(sDir)) {
        archive.directory(sDir, false);
      }
      await archive.finalize();
      await new Promise((resolve, reject) => {
        output.on('close', resolve);
        output.on('error', reject);
      });
      await dbRun(
        'INSERT INTO backups (server_id, file, name, description, size) VALUES (?, ?, ?, ?, ?)',
        [serverId, backupPath, backupName, description || '', archive.pointer()]
      );
      res.status(201).json({ success: true, message: 'Backup created', size: archive.pointer() });
    } catch (err) {
      console.error('Create backup error:', err);
      res.status(500).json({ error: 'Failed to create backup' });
    }
  });

  router.delete('/servers/:id/backups/:backupId', authenticateAPIKey, hasPermission('write'), async (req, res) => {
    try {
      const backup = await dbGet('SELECT * FROM backups WHERE id = ? AND server_id = ?', [req.params.backupId, req.params.id]);
      if (!backup) return res.status(404).json({ error: 'Backup not found' });
      if (fs.existsSync(backup.file)) {
        fs.unlinkSync(backup.file);
      }
      await dbRun('DELETE FROM backups WHERE id = ?', [backup.id]);
      res.json({ success: true, message: 'Backup deleted' });
    } catch (err) {
      console.error('Delete backup error:', err);
      res.status(500).json({ error: 'Failed to delete backup' });
    }
  });

  // ================================================
  // DISCORD LINK ENDPOINTS (admin)
  // ================================================
  router.get('/discord/links', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const links = await dbAll(`
        SELECT dl.*, u.username as panel_username
        FROM discord_links dl
        LEFT JOIN users u ON dl.panel_user_id = u.id
        ORDER BY dl.created_at DESC
      `);
      res.json({ links });
    } catch (err) {
      console.error('Get discord links error:', err);
      res.status(500).json({ error: 'Failed to get discord links' });
    }
  });

  router.post('/discord/link', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const { discord_id, panel_user_id } = req.body;
      if (!discord_id || !panel_user_id) {
        return res.status(400).json({ error: 'discord_id and panel_user_id are required' });
      }
      const user = await dbGet('SELECT id, username FROM users WHERE id = ?', [panel_user_id]);
      if (!user) return res.status(404).json({ error: 'Panel user not found' });

      const existing = await dbGet('SELECT * FROM discord_links WHERE discord_id = ?', [discord_id]);
      if (existing) {
        await dbRun('UPDATE discord_links SET panel_user_id = ?, linked_by = ? WHERE discord_id = ?',
          [panel_user_id, req.user.id, discord_id]);
        return res.json({ success: true, message: 'Link updated', discord_id, panel_user_id: user.id, panel_username: user.username });
      }

      await dbRun('INSERT INTO discord_links (discord_id, panel_user_id, linked_by) VALUES (?, ?, ?)',
        [discord_id, panel_user_id, req.user.id]);
      res.status(201).json({ success: true, discord_id, panel_user_id: user.id, panel_username: user.username });
    } catch (err) {
      console.error('Link discord error:', err);
      res.status(500).json({ error: 'Failed to link discord user' });
    }
  });

  router.delete('/discord/link/:discordId', authenticateAPIKey, hasPermission('admin'), async (req, res) => {
    try {
      const result = await dbRun('DELETE FROM discord_links WHERE discord_id = ?', [req.params.discordId]);
      if (result.changes === 0) return res.status(404).json({ error: 'Link not found' });
      res.json({ success: true, message: 'Discord link removed' });
    } catch (err) {
      console.error('Unlink discord error:', err);
      res.status(500).json({ error: 'Failed to unlink discord user' });
    }
  });

  router.get('/discord/me', authenticateAPIKey, hasPermission('read'), async (req, res) => {
    try {
      const link = await dbGet(`
        SELECT dl.*, u.username, u.email, u.role, u.status
        FROM discord_links dl
        JOIN users u ON dl.panel_user_id = u.id
        WHERE dl.panel_user_id = ?
      `, [req.user.id]);
      if (!link) return res.json({ linked: false });
      const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE owner_id = ?', [req.user.id]);
      res.json({
        linked: true,
        panel_user_id: link.panel_user_id,
        username: link.username,
        email: link.email,
        role: link.role,
        status: link.status,
        discord_id: link.discord_id,
        serverCount: serverCount ? serverCount.count : 0
      });
    } catch (err) {
      console.error('Get discord me error:', err);
      res.status(500).json({ error: 'Failed to get link info' });
    }
  });

  return router;
};
