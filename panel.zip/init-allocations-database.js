const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

function applyDatabaseUpdate() {
    const db = new sqlite3.Database('./database.db');
    
    console.log('Applying allocations database update...');
    
    const schemaSQL = fs.readFileSync(path.join(__dirname, 'database-allocations.sql'), 'utf8');
    
    const statements = schemaSQL.split(';').filter(stmt => stmt.trim().length > 0);
    
    db.serialize(() => {
        statements.forEach((statement, index) => {
            const trimmedStatement = statement.trim();
            if (trimmedStatement) {
                db.run(trimmedStatement, function(err) {
                    if (err) {
                        if (err.message.includes('duplicate column') || err.message.includes('table already exists')) {
                            console.log(`✓ Already exists: statement ${index + 1}`);
                        } else {
                            console.error(`✗ Error executing statement ${index + 1}:`, err.message);
                        }
                    } else {
                        console.log(`✓ Executed statement ${index + 1}`);
                    }
                });
            }
        });
        
        db.close((err) => {
            if (err) {
                console.error('Error closing database:', err.message);
            } else {
                console.log('Database update completed!');
            }
        });
    });
}

applyDatabaseUpdate();
